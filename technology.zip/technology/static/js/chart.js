document.addEventListener("DOMContentLoaded", () => {

const canvas=document.getElementById("memberChart");

if(!canvas)return;

new Chart(canvas,{

type:"line",

data:{

labels:["Jan","Feb","Mar","Apr","May","Jun"],

datasets:[{

label:"Members",

data:[5,18,26,32,45,60],

fill:true,

tension:.4

}]

},

options:{

responsive:true,

plugins:{

legend:{

display:true

}

}

}

});

});
