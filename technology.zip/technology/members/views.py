from django.shortcuts import redirect
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.views.generic import (
    CreateView,
    DeleteView,
    DetailView,
    ListView,
    UpdateView,
)

from .forms import MemberCreateForm
from .models import Member
from .selectors import search_members
from .services import create_member


class MemberListView(LoginRequiredMixin, ListView):
    model = Member
    template_name = "members/list.html"
    context_object_name = "members"
    paginate_by = 10

    def get_queryset(self):
        return search_members(
            self.request.GET.get("search")
        )


class MemberCreateView(LoginRequiredMixin, CreateView):

    model = Member
    form_class = MemberCreateForm
    template_name = "members/create.html"
    success_url = reverse_lazy("members:list")

    def form_valid(self, form):
        create_member(form)

        messages.success(
            self.request,
            "Member created successfully."
        )

        return redirect(self.success_url)

    def form_invalid(self, form):
        print(form.errors)
        return super().form_invalid(form)


class MemberDetailView(LoginRequiredMixin, DetailView):
    model = Member
    template_name = "members/detail.html"
    context_object_name = "member"


class MemberUpdateView(LoginRequiredMixin, UpdateView):

    model = Member
    form_class = MemberCreateForm
    template_name = "members/update.html"

    def form_valid(self, form):

        member = form.save(commit=False)

        user = member.user

        # Update User model
        user.first_name = form.cleaned_data["first_name"]
        user.last_name = form.cleaned_data["last_name"]
        user.email = form.cleaned_data["email"]

        password = form.cleaned_data.get("password")

        if password:
            user.set_password(password)

        user.save()

        # Keep existing profile picture if none uploaded
        if not self.request.FILES.get("profile_picture"):
            member.profile_picture = self.get_object().profile_picture

        member.save()

        messages.success(
            self.request,
            "Member updated successfully."
        )

        return redirect(
            "members:detail",
            pk=member.pk,
        )


class MemberDeleteView(LoginRequiredMixin, DeleteView):
    model = Member
    template_name = "members/delete.html"
    success_url = reverse_lazy("members:list")

    def form_valid(self, form):

        messages.success(
            self.request,
            "Member deleted successfully."
        )

        return super().form_valid(form)
