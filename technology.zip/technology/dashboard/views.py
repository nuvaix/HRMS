
from django.contrib.auth.decorators import login_required
from django.shortcuts import render

from members.models import Member
from documents.models import Document

from leaves.selectors import (
    leave_statistics,
    get_recent_leaves,
)

from shifts.selectors import (
    shift_statistics,
    get_recent_shifts,
)

from attendance.selectors import (
    attendance_statistics,
    get_recent_attendance,
)

from payroll.selectors import (
    payroll_statistics,
    get_recent_payroll,
)

from chat.selectors import (
    chat_statistics,
    get_recent_conversations,
)


@login_required
def home(request):

    # ==========================
    # Member Statistics
    # ==========================

    total_members = Member.objects.count()

    active_members = Member.objects.filter(
        status="ACTIVE"
    ).count()

    inactive_members = Member.objects.exclude(
        status="ACTIVE"
    ).count()

    recent_members = (
        Member.objects
        .select_related("user")
        .order_by("-created_at")[:5]
    )

    # ==========================
    # Document Statistics
    # ==========================

    total_documents = Document.objects.count()

    active_documents = Document.objects.filter(
        status="ACTIVE"
    ).count()

    inactive_documents = Document.objects.exclude(
        status="ACTIVE"
    ).count()

    recent_documents = (
        Document.objects
        .select_related(
            "member",
            "member__user",
        )
        .order_by("-created_at")[:5]
    )

    # ==========================
    # Leave
    # ==========================

    leave_stats = leave_statistics()

    recent_leaves = get_recent_leaves()

    # ==========================
    # Shift
    # ==========================

    shift_stats = shift_statistics()

    recent_shifts = get_recent_shifts()

    # ==========================
    # Attendance
    # ==========================

    attendance_stats = attendance_statistics()

    recent_attendance = get_recent_attendance()

    # ==========================
    # Payroll
    # ==========================

    payroll_stats = payroll_statistics()

    recent_payroll = get_recent_payroll()


    # ==========================
    # Chat Statistics
    # ==========================

    chat_stats = chat_statistics()

    recent_conversations = get_recent_conversations()

    # ==========================
    # Context
    # ==========================

    context = {

        # Members

        "total_members": total_members,
        "active_members": active_members,
        "inactive_members": inactive_members,
        "recent_members": recent_members,

        # Documents

        "total_documents": total_documents,
        "active_documents": active_documents,
        "inactive_documents": inactive_documents,
        "recent_documents": recent_documents,

        # Leaves

        "recent_leaves": recent_leaves,

        # Shifts

        "recent_shifts": recent_shifts,

        # Attendance

        "recent_attendance": recent_attendance,

        # Payroll

        "recent_payroll": recent_payroll,

        # Chat

        # Chat

        "total_conversations": chat_stats["total_conversations"],

        "total_messages": chat_stats["total_messages"],

        "unread_messages": chat_stats["unread_messages"],

        "recent_conversations": recent_conversations,

    }

    context.update(leave_stats)

    context.update(shift_stats)

    context.update(attendance_stats)

    context.update(payroll_stats)

    context.update(chat_stats)

    return render(

        request,

        "dashboard/home.html",

        context,

    )
