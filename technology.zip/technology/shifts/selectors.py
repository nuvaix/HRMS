from django.db.models import Q

from .models import Shift


def search_shifts(search=None):

    queryset = (
        Shift.objects
        .select_related(
            "member",
            "member__user",
        )
        .order_by("-created_at")
    )

    if search:

        queryset = queryset.filter(

            Q(member__user__first_name__icontains=search)

            |

            Q(member__user__last_name__icontains=search)

            |

            Q(member__employee_id__icontains=search)

            |

            Q(shift_type__icontains=search)

        )

    return queryset


def get_recent_shifts():

    return (

        Shift.objects

        .select_related(

            "member",

            "member__user",

        )

        .order_by("-created_at")[:5]

    )



def shift_statistics():

    queryset = Shift.objects.all()

    return {

        "total_shifts": queryset.count(),

        "active_shifts": queryset.filter(
            is_active=True
        ).count(),

        "inactive_shifts": queryset.filter(
            is_active=False
        ).count(),

        "morning_shifts": queryset.filter(
            shift_type="MORNING"
        ).count(),

        "afternoon_shifts": queryset.filter(
            shift_type="AFTERNOON"
        ).count(),

        "evening_shifts": queryset.filter(
            shift_type="EVENING"
        ).count(),

        "night_shifts": queryset.filter(
            shift_type="NIGHT"
        ).count(),

    }



def get_active_shifts():

    return (

        Shift.objects

        .filter(
            is_active=True
        )

        .select_related(
            "member",
            "member__user",
        )

        .order_by(
            "start_time"
        )

    )



def get_shift(pk):

    return (

        Shift.objects

        .select_related(
            "member",
            "member__user",
        )

        .get(
            pk=pk
        )

    )
