
from django.urls import path

from . import views

app_name = "chat"

urlpatterns = [

    # Inbox
    path(
        "",
        views.inbox,
        name="inbox",
    ),

    # Start a new chat
    path(
        "new/",
        views.new_chat,
        name="new_chat",
    ),

    # Create/Open a private chat
    path(
        "start/<uuid:user_id>/",
        views.start_chat,
        name="start_chat",
    ),

    # Conversation
    path(
        "conversation/<int:pk>/",
        views.conversation,
        name="conversation",
    ),

    # Send Message
    path(
        "conversation/<int:pk>/send/",
        views.send,
        name="send",
    ),

    path(

        "notifications/",

        views.notifications,

        name="notifications",

    ),

    path(
        "notifications/<uuid:pk>/read/",
        views.mark_notification_read,
        name="mark_notification_read",
    ),

    path(
        "notifications/read-all/",
        views.mark_all_notifications_read,
        name="mark_all_notifications_read",
    ), 

]

