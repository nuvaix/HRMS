
from django.conf import settings
from django.db import models
from .storage import (
    chat_upload_path,
    image_upload_path,
)

from .validators import (
    validate_document,
    validate_image,
)

User = settings.AUTH_USER_MODEL


class Conversation(models.Model):
    """
    One-to-one or group conversation.
    """

    PRIVATE = "private"
    GROUP = "group"
    DEPARTMENT = "department"

    TYPE_CHOICES = [
        (PRIVATE, "Private"),
        (GROUP, "Group"),
        (DEPARTMENT, "Department"),
    ]

    conversation_type = models.CharField(
        max_length=20,
        choices=TYPE_CHOICES,
        default=PRIVATE,
    )

    name = models.CharField(
        max_length=255,
        blank=True,
    )

    participants = models.ManyToManyField(
        User,
        related_name="chat_conversations",
    )

    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name="created_conversations",
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
    )

    updated_at = models.DateTimeField(
        auto_now=True,
    )

    class Meta:
        ordering = ["-updated_at"]

    def __str__(self):
        if self.name:
            return self.name
        return f"Conversation {self.pk}"


class Message(models.Model):

    conversation = models.ForeignKey(
        Conversation,
        related_name="messages",
        on_delete=models.CASCADE,
    )

    sender = models.ForeignKey(
        User,
        related_name="sent_messages",
        on_delete=models.CASCADE,
    )

    body = models.TextField(
        blank=True,
    )

    attachment = models.FileField(
        upload_to=chat_upload_path,
        validators=[validate_document],
        blank=True,
        null=True,
    )  

    image = models.ImageField(
        upload_to=image_upload_path,
        validators=[validate_image],
        blank=True,
        null=True,
    ) 

    reply_to = models.ForeignKey(
        "self",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="replies",
    )

    edited = models.BooleanField(
        default=False,
    )

    deleted = models.BooleanField(
        default=False,
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
    )

    updated_at = models.DateTimeField(
        auto_now=True,
    )

    class Meta:
        ordering = ["created_at"]

    def __str__(self):
        return f"Message #{self.pk}"

    @property
    def delivered_count(self):
        return self.receipts.exclude(
            delivered_at=None
        ).count()

    @property
    def read_count(self):
        return self.receipts.exclude(
            read_at=None
        ).count()

    @property
    def is_read(self):
        return self.read_count > 0


class MessageReceipt(models.Model):

    message = models.ForeignKey(
        Message,
        related_name="receipts",
        on_delete=models.CASCADE,
    )

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
    )

    delivered_at = models.DateTimeField(
        null=True,
        blank=True,
    )

    read_at = models.DateTimeField(
        null=True,
        blank=True,
    )

    class Meta:
        unique_together = (
            "message",
            "user",
        )

    def __str__(self):
        return f"{self.user} - {self.message_id}"


class MessageReaction(models.Model):

    message = models.ForeignKey(
        Message,
        related_name="reactions",
        on_delete=models.CASCADE,
    )

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
    )

    emoji = models.CharField(
        max_length=20,
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
    )

    class Meta:
        unique_together = (
            "message",
            "user",
            "emoji",
        )

    def __str__(self):
        return self.emoji


class Notification(models.Model):

    MESSAGE = "message"

    SYSTEM = "system"

    TYPE_CHOICES = [

        (MESSAGE, "Message"),

        (SYSTEM, "System"),

    ]

    recipient = models.ForeignKey(

        User,

        on_delete=models.CASCADE,

        related_name="notifications",

    )

    sender = models.ForeignKey(

        User,

        on_delete=models.CASCADE,

        related_name="sent_notifications",

        null=True,

        blank=True,

    )

    conversation = models.ForeignKey(

        Conversation,

        on_delete=models.CASCADE,

        null=True,

        blank=True,

    )

    notification_type = models.CharField(

        max_length=20,

        choices=TYPE_CHOICES,

        default=MESSAGE,

    )

    title = models.CharField(

        max_length=255,

    )

    body = models.TextField()

    is_read = models.BooleanField(

        default=False,

    )

    created_at = models.DateTimeField(

        auto_now_add=True,

    )

    class Meta:

        ordering = ["-created_at"]

    def __str__(self):

        return self.title
