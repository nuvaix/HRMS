from django.db import transaction
from django.utils import timezone
from .models import Attendance
from .constants import PRESENT
from .constants import ABSENT
from .constants import LATE
from .constants import HALF_DAY
from .constants import ON_LEAVE


@transaction.atomic
def create_attendance(*, data):

    attendance = Attendance.objects.create(

        member=data["member"],

        date=data["date"],

        check_in=data["check_in"],

        check_out=data.get("check_out"),

        status=data["status"],

        remarks=data.get("remarks", ""),

    )

    return attendance


@transaction.atomic
def update_attendance(*, attendance, data):

    attendance.member = data["member"]

    attendance.date = data["date"]

    attendance.check_in = data["check_in"]

    attendance.check_out = data.get("check_out")

    attendance.status = data["status"]

    attendance.remarks = data.get("remarks", "")

    attendance.save()

    return attendance



@transaction.atomic
def delete_attendance(*, attendance):

    attendance.delete()


@transaction.atomic
def employee_check_in(*, member):

    today = timezone.localdate()

    now = timezone.localtime().time()

    attendance = Attendance.objects.create(

        member=member,

        date=today,

        check_in=now,

    )

    return attendance



@transaction.atomic
def employee_check_out(*, attendance):

    attendance.check_out = timezone.localtime().time()

    attendance.save()

    return attendance



@transaction.atomic
def mark_present(*, attendance):

    attendance.status = PRESENT

    attendance.save()

    return attendance



@transaction.atomic
def mark_absent(*, attendance):

    attendance.status = ABSENT

    attendance.save()

    return attendance



@transaction.atomic
def mark_late(*, attendance):

    attendance.status = LATE

    attendance.save()

    return attendance



@transaction.atomic
def mark_half_day(*, attendance):

    attendance.status = HALF_DAY

    attendance.save()

    return attendance



@transaction.atomic
def mark_on_leave(*, attendance):

    attendance.status = ON_LEAVE

    attendance.save()

    return attendance
