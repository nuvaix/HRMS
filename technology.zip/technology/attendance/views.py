from django.shortcuts import render

# Create your views here.

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404

from .models import Attendance
from .forms import AttendanceForm

from .selectors import (
    attendance_statistics,
    get_recent_attendance,
)

from .services import (
    create_attendance,
    update_attendance,
    delete_attendance,
)

@login_required
def attendance_list(request):

    attendances = (
        Attendance.objects
        .select_related(
            "member",
            "member__user",
        )
        .order_by("-date")
    )

    context = {

        "attendances": attendances,

        **attendance_statistics(),

    }

    return render(
        request,
        "attendance/list.html",
        context,
    )



@login_required
def attendance_detail(request, pk):

    attendance = get_object_or_404(
        Attendance.objects.select_related(
            "member",
            "member__user",
        ),
        pk=pk,
    )

    return render(
        request,
        "attendance/detail.html",
        {
            "attendance": attendance,
        },
    )



@login_required
def attendance_create(request):

    form = AttendanceForm(request.POST or None)

    if form.is_valid():

        create_attendance(
            data=form.cleaned_data,
        )

        return redirect("attendance:list")

    return render(
        request,
        "attendance/form.html",
        {
            "form": form,
            "title": "Create Attendance",
        },
    )


@login_required
def attendance_update(request, pk):

    attendance = get_object_or_404(
        Attendance,
        pk=pk,
    )

    form = AttendanceForm(
        request.POST or None,
        instance=attendance,
    )

    if form.is_valid():

        update_attendance(
            attendance=attendance,
            data=form.cleaned_data,
        )

        return redirect(
            "attendance:detail",
            attendance.pk,
        )

    return render(
        request,
        "attendance/form.html",
        {
            "form": form,
            "title": "Update Attendance",
        },
    )




@login_required
def attendance_delete(request, pk):

    attendance = get_object_or_404(
        Attendance,
        pk=pk,
    )

    if request.method == "POST":

        delete_attendance(
            attendance=attendance,
        )

        return redirect("attendance:list")

    return render(
        request,
        "attendance/delete.html",
        {
            "attendance": attendance,
        },
    )


@login_required
def attendance_dashboard(request):

    context = {

        **attendance_statistics(),

        "recent_attendance": get_recent_attendance(),

    }

    return render(
        request,
        "attendance/dashboard.html",
        context,
    )
