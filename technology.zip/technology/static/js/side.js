document.addEventListener("DOMContentLoaded", () => {

    const sidebar = document.querySelector(".sidebar");

    const toggle = document.getElementById("sidebarToggle");

    if (!toggle) return;

    toggle.addEventListener("click", () => {

        sidebar.classList.toggle("collapsed");

    });

});
