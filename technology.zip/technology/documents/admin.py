from django.contrib import admin

# Register your models here.

from django.contrib import admin

from .models import Document


@admin.register(Document)
class DocumentAdmin(admin.ModelAdmin):

    list_display = (
        "title",
        "member",
        "document_type",
        "status",
        "created_at",
    )

    list_filter = (
        "document_type",
        "status",
    )

    search_fields = (
        "title",
        "member__employee_id",
        "member__user__first_name",
        "member__user__last_name",
    )
