from django.contrib import admin

# Register your models here.


from django.contrib import admin

from .models import (
    Conversation,
    Message,
    MessageReaction,
    MessageReceipt,
)


class MessageInline(admin.TabularInline):
    model = Message
    extra = 0
    readonly_fields = (
        "sender",
        "body",
        "created_at",
    )
    show_change_link = True


@admin.register(Conversation)
class ConversationAdmin(admin.ModelAdmin):

    list_display = (
        "id",
        "name",
        "conversation_type",
        "created_by",
        "created_at",
    )

    list_filter = (
        "conversation_type",
        "created_at",
    )

    search_fields = (
        "name",
        "participants__username",
        "participants__first_name",
        "participants__last_name",
    )

    filter_horizontal = (
        "participants",
    )

    inlines = [
        MessageInline,
    ]


class ReceiptInline(admin.TabularInline):
    model = MessageReceipt
    extra = 0


class ReactionInline(admin.TabularInline):
    model = MessageReaction
    extra = 0


@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):

    list_display = (
        "id",
        "conversation",
        "sender",
        "short_body",
        "edited",
        "deleted",
        "created_at",
    )

    list_filter = (
        "edited",
        "deleted",
        "created_at",
    )

    search_fields = (
        "body",
        "sender__username",
        "sender__first_name",
        "sender__last_name",
    )

    readonly_fields = (
        "created_at",
        "updated_at",
    )

    inlines = [
        ReceiptInline,
        ReactionInline,
    ]

    def short_body(self, obj):
        if not obj.body:
            return "-"
        return obj.body[:60]


@admin.register(MessageReceipt)
class MessageReceiptAdmin(admin.ModelAdmin):

    list_display = (
        "message",
        "user",
        "delivered_at",
        "read_at",
    )

    list_filter = (
        "delivered_at",
        "read_at",
    )

    search_fields = (
        "user__username",
        "message__body",
    )


@admin.register(MessageReaction)
class MessageReactionAdmin(admin.ModelAdmin):

    list_display = (
        "message",
        "user",
        "emoji",
        "created_at",
    )

    search_fields = (
        "user__username",
        "emoji",
    )

