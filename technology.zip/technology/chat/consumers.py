
import json

from channels.generic.websocket import AsyncWebsocketConsumer

from asgiref.sync import sync_to_async

from .models import (
    Conversation,
    Message,
    MessageReceipt,
)


class ChatConsumer(AsyncWebsocketConsumer):

    async def connect(self):

        # Get conversation ID from URL
        self.conversation_id = self.scope["url_route"]["kwargs"]["conversation_id"]

        # Create a group name
        self.room_group_name = f"chat_{self.conversation_id}"

        # Join the group
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name,
        )

        # Accept WebSocket connection
        await self.accept()
        

        await self.mark_user_online()


        await self.channel_layer.group_send(

            self.room_group_name,

            {

                "type": "presence_update",

                "user_id": self.scope["user"].id,

                "username": self.scope["user"].email,

                "is_online": True,

                "last_seen": None,

            },

        )


        message_ids = await self.mark_messages_delivered()

        for message_id in message_ids:

            await self.channel_layer.group_send(

                self.room_group_name,

                {

                    "type": "message_delivered",

                    "message_id": message_id,

                },

            )

        print(
            f"Connected to conversation {self.conversation_id}"
        )


        read_ids = await self.mark_messages_read()

        for message_id in read_ids:

            await self.channel_layer.group_send(

                self.room_group_name,

                {

                    "type": "message_read",

                    "message_id": message_id,

                },

            ) 



    async def disconnect(self, close_code):

        await self.mark_user_offline()
        

        await self.channel_layer.group_send(

            self.room_group_name,

            {

                "type": "presence_update",

                "user_id": self.scope["user"].id,

                "username": self.scope["user"].email,

                "is_online": False,

                "last_seen": self.scope["user"].last_seen.strftime(
                    "%Y-%m-%d %H:%M"
                ),

            },

        )


        await self.channel_layer.group_discard(

            self.room_group_name,

            self.channel_name,

        )

        print(

            f"Disconnected from conversation {self.conversation_id}"

        )



    @sync_to_async
    def save_message(self, message_text):

        conversation = Conversation.objects.get(
            id=self.conversation_id
        )

        message = Message.objects.create(

            conversation=conversation,

            sender=self.scope["user"],

            body=message_text,

        )

        for participant in conversation.participants.exclude(
            id=self.scope["user"].id
        ):

            MessageReceipt.objects.create(

                message=message,

                user=participant,

            )

        return message

    

    @sync_to_async
    def mark_messages_delivered(self):

        receipts = MessageReceipt.objects.filter(

            user=self.scope["user"],

            delivered_at=None,

        )

        updated_messages = []

        for receipt in receipts:

            receipt.mark_delivered()

            updated_messages.append(receipt.message.id)

        return updated_messages

    
    @sync_to_async
    def mark_messages_read(self):

        receipts = MessageReceipt.objects.filter(

            user=self.scope["user"],

            read_at=None,

        )

        updated_messages = []

        for receipt in receipts:

            receipt.mark_read()

            updated_messages.append(receipt.message.id)

        return updated_messages

    
    @sync_to_async
    def mark_user_online(self):

        user = self.scope["user"]

        if user.is_authenticated:

            user.mark_online()


    @sync_to_async
    def mark_user_offline(self):

        user = self.scope["user"]

        if user.is_authenticated:

            user.mark_offline()


    async def receive(self, text_data):

        data = json.loads(text_data)

        event = data.get("event")

        if event == "typing":

            await self.channel_layer.group_send(

                self.room_group_name,

                {

                    "type": "typing_indicator",

                    "sender": self.scope["user"].email,

                },

            )

            return

        if event == "stop_typing":

            await self.channel_layer.group_send(

                self.room_group_name,

                {

                    "type": "stop_typing",

                    "sender": self.scope["user"].email,

                },

            )

            return

        message_text = data.get("message", "").strip()

        if not message_text:

            return

        message = await self.save_message(message_text)

        await self.channel_layer.group_send(

            self.room_group_name,

            {

                "type": "chat_message",

                "id": message.id,

                "message": message.body,

                "sender": message.sender.email,

                "created_at": message.created_at.strftime("%H:%M"),

            },

        )



        await self.channel_layer.group_send(

            self.room_group_name,

            {   

                "type": "chat_message",

                "message": message,

                "sender": sender,

            },

        )



    async def chat_message(self, event):

        await self.send(

            text_data=json.dumps(

                {

                    "id": event["id"],

                    "message": event["message"],

                    "sender": event["sender"],

                    "created_at": event["created_at"],

                }

            )

        )



    async def typing_indicator(self, event):

        await self.send(

            text_data=json.dumps(

                {

                    "event": "typing",

                    "sender": event["sender"],

                }

            )

        )


    async def stop_typing(self, event):

        await self.send(

            text_data=json.dumps(

                {

                    "event": "stop_typing",

                    "sender": event["sender"],

                }

            )

        )



    async def message_delivered(self, event):

        await self.send(

            text_data=json.dumps(

                {

                    "event": "delivered",

                    "message_id": event["message_id"],

                }

            )

        )


    async def message_read(self, event):

        await self.send(

            text_data=json.dumps(

                {

                    "event": "read",

                    "message_id": event["message_id"],

                }

            )

        )


    async def presence_update(self, event):

        await self.send(

            text_data=json.dumps(

                {

                    "event": "presence",

                    "user_id": event["user_id"],

                    "username": event["username"],

                    "is_online": event["is_online"],

                    "last_seen": event.get("last_seen"),

                }

            )

        )


class NotificationConsumer(AsyncWebsocketConsumer):

    async def connect(self):

        self.user = self.scope["user"]

        if self.user.is_anonymous:

            await self.close()

            return

        self.group_name = f"notifications_{self.user.id}"

        await self.channel_layer.group_add(

            self.group_name,

            self.channel_name,

        )

        await self.accept()


    async def disconnect(self, close_code):

        await self.channel_layer.group_discard(

            self.group_name,

            self.channel_name,

        )


    async def notification(self, event):

        await self.send(

            text_data=json.dumps(

                event["data"]

            )

        )
