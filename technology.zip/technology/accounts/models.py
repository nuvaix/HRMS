from django.db import models

# Create your models here.

from django.db import models

from django.contrib.auth.models import AbstractUser

from .managers import UserManager

from uuid import uuid4


from django.utils import timezone

class User(AbstractUser):

    username = None

    class Role(models.TextChoices):

        SUPER_ADMIN = "SUPER_ADMIN", "Super Admin"

        ADMIN = "ADMIN", "Admin"

        MANAGER = "MANAGER", "Manager"

        STAFF = "STAFF", "Staff"


    is_online = models.BooleanField(
        default=False
    )

    last_seen = models.DateTimeField(
        default=timezone.now
    )


    id = models.UUIDField(
        primary_key=True,
        default=uuid4,
        editable=False
    )

    email = models.EmailField(
        unique=True
    )

    first_name = models.CharField(
        max_length=150
    )

    last_name = models.CharField(
        max_length=150
    )

    phone = models.CharField(
        max_length=20,
        blank=True
    )

    avatar = models.ImageField(
        upload_to="avatars/",
        blank=True,
        null=True
    )

    role = models.CharField(
        max_length=20,
        choices=Role.choices,
        default=Role.STAFF
    )

    is_verified = models.BooleanField(
        default=False
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    updated_at = models.DateTimeField(
        auto_now=True
    )

    USERNAME_FIELD = "email"

    REQUIRED_FIELDS = []

    objects = UserManager()


    def mark_online(self):

        self.is_online = True

        self.save(update_fields=["is_online"])


    def mark_offline(self):

        self.is_online = False

        self.last_seen = timezone.now()

        self.save(
            update_fields=[
                "is_online",
                "last_seen",
            ]
        )



    def __str__(self):
        return self.email
