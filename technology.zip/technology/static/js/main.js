document.addEventListener("DOMContentLoaded", () => {

    // ==========================
    // Image Preview
    // ==========================

    const imageInput = document.querySelector(
        'input[type="file"]'
    );

    if (imageInput) {

        imageInput.addEventListener("change", function () {

            const file = this.files[0];

            if (!file) return;

            const reader = new FileReader();

            reader.onload = function (e) {

                document
                    .getElementById("imagePreview")
                    .src = e.target.result;

            };

            reader.readAsDataURL(file);

        });

    }

    // ==========================
    // Password Strength
    // ==========================

    const password = document.querySelector(
        'input[type="password"]'
    );

    if (password) {

        const strength = document.createElement("small");

        strength.classList.add("text-muted");

        password.after(strength);

        password.addEventListener("keyup", () => {

            const value = password.value;

            if (value.length < 6) {

                strength.innerHTML =
                    "<span class='text-danger'>Weak password</span>";

            } else if (value.length < 10) {

                strength.innerHTML =
                    "<span class='text-warning'>Medium password</span>";

            } else {

                strength.innerHTML =
                    "<span class='text-success'>Strong password</span>";

            }

        });

    }

});
