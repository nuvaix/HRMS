from django.db.models import Q

from .models import Document


def search_documents(search=None):
    """
    Search documents by:
    - Title
    - Member First Name
    - Member Last Name
    - Employee ID
    - Document Type
    """

    queryset = (
        Document.objects
        .select_related(
            "member",
            "member__user",
            "uploaded_by",
        )
        .order_by("-created_at")
    )

    if search:

        queryset = queryset.filter(

            Q(title__icontains=search)

            |

            Q(member__employee_id__icontains=search)

            |

            Q(member__user__first_name__icontains=search)

            |

            Q(member__user__last_name__icontains=search)

            |

            Q(document_type__icontains=search)

        )

    return queryset
