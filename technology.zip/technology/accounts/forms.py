from django import forms

from django.contrib.auth.forms import AuthenticationForm

from .models import User


class LoginForm(AuthenticationForm):

    username = forms.EmailField()

    password = forms.CharField(
        widget=forms.PasswordInput
    )


class UserCreationForm(forms.ModelForm):

    password = forms.CharField(
        widget=forms.PasswordInput
    )

    class Meta:

        model = User

        fields = (
            "first_name",
            "last_name",
            "email",
            "phone",
            "role",
            "password",
        )

    def save(self, commit=True):

        user = super().save(commit=False)

        user.set_password(self.cleaned_data["password"])

        if commit:
            user.save()

        return user
