from django import forms

from .models import Payroll


class PayrollForm(forms.ModelForm):

    class Meta:

        model = Payroll

        fields = [

            "member",

            "month",

            "year",

            "basic_salary",

            "housing_allowance",

            "transport_allowance",

            "medical_allowance",

            "bonus",

            "overtime",

            "tax",

            "pension",

            "deductions",

            "status",

            "remarks",

        ]

        widgets = {

            "member": forms.Select(

                attrs={

                    "class": "form-select",

                }

            ),

            "month": forms.NumberInput(

                attrs={

                    "class": "form-control",

                    "min": 1,

                    "max": 12,

                }

            ),

            "year": forms.NumberInput(

                attrs={

                    "class": "form-control",

                }

            ),

            "basic_salary": forms.NumberInput(

                attrs={

                    "class": "form-control",

                    "step": "0.01",

                }

            ),

            "housing_allowance": forms.NumberInput(

                attrs={

                    "class": "form-control",

                    "step": "0.01",

                }

            ),

            "transport_allowance": forms.NumberInput(

                attrs={

                    "class": "form-control",

                    "step": "0.01",

                }

            ),

            "medical_allowance": forms.NumberInput(

                attrs={

                    "class": "form-control",

                    "step": "0.01",

                }

            ),

            "bonus": forms.NumberInput(

                attrs={

                    "class": "form-control",

                    "step": "0.01",

                }

            ),

            "overtime": forms.NumberInput(

                attrs={

                    "class": "form-control",

                    "step": "0.01",

                }

            ),

            "tax": forms.NumberInput(

                attrs={

                    "class": "form-control",

                    "step": "0.01",

                }

            ),

            "pension": forms.NumberInput(

                attrs={

                    "class": "form-control",

                    "step": "0.01",

                }

            ),

            "deductions": forms.NumberInput(

                attrs={

                    "class": "form-control",

                    "step": "0.01",

                }

            ),

            "status": forms.Select(

                attrs={

                    "class": "form-select",

                }

            ),

            "remarks": forms.Textarea(

                attrs={

                    "class": "form-control",

                    "rows": 4,

                }

            ),

        }

    def clean_month(self):

        month = self.cleaned_data["month"]

        if month < 1 or month > 12:

            raise forms.ValidationError(

                "Month must be between 1 and 12."

            )

        return month


    def clean_year(self):

        year = self.cleaned_data["year"]

        if year < 2020:

            raise forms.ValidationError(

                "Invalid payroll year."

            )

        return year

    def clean_basic_salary(self):

        salary = self.cleaned_data["basic_salary"]

        if salary <= 0:

            raise forms.ValidationError(

                "Salary must be greater than zero."

            )

        return salary

