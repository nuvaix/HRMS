from django import forms

from .models import Attendance


class AttendanceForm(forms.ModelForm):

    class Meta:

        model = Attendance

        fields = (
            "member",
            "date",
            "check_in",
            "check_out",
            "status",
            "remarks",
        )

        widgets = {

            "date": forms.DateInput(
                attrs={
                    "type": "date",
                    "class": "form-control",
                }
            ),

            "check_in": forms.TimeInput(
                attrs={
                    "type": "time",
                    "class": "form-control",
                }
            ),

            "check_out": forms.TimeInput(
                attrs={
                    "type": "time",
                    "class": "form-control",
                }
            ),

            "member": forms.Select(
                attrs={
                    "class": "form-select",
                }
            ),

            "status": forms.Select(
                attrs={
                    "class": "form-select",
                }
            ),

            "remarks": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "rows": 4,
                }
            ),
        }

def clean(self):

    cleaned_data = super().clean()

    check_in = cleaned_data.get("check_in")

    check_out = cleaned_data.get("check_out")

    if check_in and check_out:

        if check_out <= check_in:

            raise forms.ValidationError(
                "Check-out time must be later than check-in time."
            )

    return cleaned_data
