
from django.contrib.auth import get_user_model
from django.db.models import Max, Q

from .models import (
    Conversation,
    Message,
    Notification,
)


User = get_user_model()


def get_user_conversations(user):
    """
    Return all conversations a user belongs to.
    """

    return (
        Conversation.objects
        .filter(participants=user)
        .prefetch_related("participants")
        .annotate(
            last_activity=Max("messages__created_at")
        )
        .order_by("-last_activity", "-updated_at")
    )


def get_conversation(conversation_id):

    return (
        Conversation.objects
        .prefetch_related("participants")
        .get(id=conversation_id)
    )


def get_conversation_messages(conversation):

    return (
        Message.objects
        .filter(
            conversation=conversation,
            deleted=False,
        )
        .select_related(
            "sender",
            "reply_to",
        )
        .prefetch_related(
            "reactions",
            "receipts",
        )
        .order_by("created_at")
    )


def get_recent_conversations(limit=5):

    return (
        Conversation.objects
        .annotate(
            last_activity=Max("messages__created_at")
        )
        .order_by("-last_activity")[:limit]
    )



def search_users(query, current_user=None):

    users = User.objects.filter(
        is_active=True
    )

    if current_user:

        users = users.exclude(
            id=current_user.id
        )

    if query:

        users = users.filter(

            Q(first_name__icontains=query)
            |
            Q(last_name__icontains=query)
            |
            Q(email__icontains=query)
            |
            Q(phone__icontains=query)

        )

    return users.order_by(
        "first_name",
        "email",
    )


def chat_statistics():

    return {

        "total_conversations":
            Conversation.objects.count(),

        "total_messages":
            Message.objects.count(),

        "unread_messages":
            0,

    }


def get_recent_notifications(

    user,

    limit=10,

):

    return (

        Notification.objects

        .filter(

            recipient=user,

        )

        .select_related(

            "sender",

            "conversation",

        )

        .order_by(

            "-created_at",

        )[:limit]

    )



def get_unread_notifications(user):

    return (

        Notification.objects

        .filter(

            recipient=user,

            is_read=False,

        )

        .select_related(

            "sender",

            "conversation",

        )

        .order_by(

            "-created_at",

        )

    )



def get_unread_notification_count(user):

    return (

        Notification.objects

        .filter(

            recipient=user,

            is_read=False,

        )

        .count()

    )


def notification_statistics(user):

    notifications = Notification.objects.filter(

        recipient=user,

    )

    return {

        "total": notifications.count(),

        "unread": notifications.filter(

            is_read=False,

        ).count(),

        "read": notifications.filter(

            is_read=True,

        ).count(),

    }



def get_user_notifications(user):

    return (

        Notification.objects

        .filter(

            recipient=user,

        )

        .select_related(

            "sender",

            "conversation",

        )

        .order_by(

            "-created_at",

        )

    )

