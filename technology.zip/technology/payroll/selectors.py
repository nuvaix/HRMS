from django.db.models import Sum

from .models import Payroll


def get_payrolls():

    return (

        Payroll.objects

        .select_related(

            "member",

            "member__user",

        )

        .all()

    )


def get_payroll(pk):

    return (

        Payroll.objects

        .select_related(

            "member",

            "member__user",

        )

        .get(pk=pk)

    )


def get_recent_payroll(limit=5):

    return (

        Payroll.objects

        .select_related(

            "member",

            "member__user",

        )

        .order_by(

            "-year",

            "-month",

            "-created_at",

        )[:limit]

    )


def get_employee_payroll(member):

    return (

        Payroll.objects

        .filter(

            member=member,

        )

        .order_by(

            "-year",

            "-month",

        )

    )

def payroll_statistics():

    queryset = Payroll.objects.all()

    return {

        "total_payroll": queryset.count(),

        "gross_payroll": queryset.aggregate(

            total=Sum(

                "gross_salary"

            )

        )["total"] or 0,

        "net_payroll": queryset.aggregate(

            total=Sum(

                "net_salary"

            )

        )["total"] or 0,

        "total_tax": queryset.aggregate(

            total=Sum(

                "tax"

            )

        )["total"] or 0,

        "total_pension": queryset.aggregate(

            total=Sum(

                "pension"

            )

        )["total"] or 0,

        "total_bonus": queryset.aggregate(

            total=Sum(

                "bonus"

            )

        )["total"] or 0,

        "total_overtime": queryset.aggregate(

            total=Sum(

                "overtime"

            )

        )["total"] or 0,

    }


def get_monthly_payroll(

    month,

    year,

):

    return (

        Payroll.objects

        .filter(

            month=month,

            year=year,

        )

        .select_related(

            "member",

            "member__user",

        )

    )



def get_yearly_payroll(year):

    return (

        Payroll.objects

        .filter(

            year=year,

        )

        .select_related(

            "member",

            "member__user",

        )

    )


def get_department_payroll(

    department,

):

    return (

        Payroll.objects

        .filter(

            member__department=department,

        )

        .select_related(

            "member",

            "member__user",

        )

    )
