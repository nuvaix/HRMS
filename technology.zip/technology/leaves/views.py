from django.shortcuts import render

# Create your views here.

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import redirect
from django.urls import reverse_lazy
from django.views.generic import (
    CreateView,
    DeleteView,
    DetailView,
    ListView,
    UpdateView,
)

from .forms import LeaveCreateForm
from .models import Leave
from .selectors import search_leaves
from .services import create_leave


class LeaveListView(LoginRequiredMixin, ListView):

    model = Leave
    template_name = "leaves/list.html"
    context_object_name = "leaves"
    paginate_by = 10

    def get_queryset(self):

        return search_leaves(
            search=self.request.GET.get("search"),
            status=self.request.GET.get("status"),
            leave_type=self.request.GET.get("leave_type"),
        )


class LeaveCreateView(LoginRequiredMixin, CreateView):

    model = Leave
    form_class = LeaveCreateForm
    template_name = "leaves/create.html"
    success_url = reverse_lazy("leaves:list")

    def form_valid(self, form):

        create_leave(form)

        messages.success(
            self.request,
            "Leave request submitted successfully."
        )

        return redirect(self.success_url)

    def form_invalid(self, form):

        print(form.errors)

        return super().form_invalid(form)


class LeaveDetailView(LoginRequiredMixin, DetailView):

    model = Leave
    template_name = "leaves/detail.html"
    context_object_name = "leave"


class LeaveUpdateView(LoginRequiredMixin, UpdateView):

    model = Leave
    form_class = LeaveCreateForm
    template_name = "leaves/update.html"
    success_url = reverse_lazy("leaves:list")

    def form_valid(self, form):

        messages.success(
            self.request,
            "Leave updated successfully."
        )

        return super().form_valid(form)


class LeaveDeleteView(LoginRequiredMixin, DeleteView):

    model = Leave
    template_name = "leaves/delete.html"
    success_url = reverse_lazy("leaves:list")

    def form_valid(self, form):

        messages.success(
            self.request,
            "Leave deleted successfully."
        )

        return super().form_valid(form)
