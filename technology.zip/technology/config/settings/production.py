from .base import *

DEBUG = False

ALLOWED_HOSTS = [
    # Add your domain(s) here later, for example:
    # "yourdomain.com",
    # ".up.railway.app",
]

SECURE_SSL_REDIRECT = True
