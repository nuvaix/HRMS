import random


def generate_employee_id():

    return f"EMP-{random.randint(100000,999999)}"
