ACTIVE = "Active"
INACTIVE = "Inactive"

STATUS_CHOICES = (
    (ACTIVE, "Active"),
    (INACTIVE, "Inactive"),
)

MALE = "Male"
FEMALE = "Female"

GENDER_CHOICES = (
    (MALE, "Male"),
    (FEMALE, "Female"),
)
