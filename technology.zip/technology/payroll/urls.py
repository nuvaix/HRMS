from django.urls import path

from . import views

app_name = "payroll"

urlpatterns = [

    path(
        "",
        views.PayrollListView.as_view(),
        name="list",
    ),

    path(
        "create/",
        views.PayrollCreateView.as_view(),
        name="create",
    ),

    path(
        "<int:pk>/",
        views.PayrollDetailView.as_view(),
        name="detail",
    ),

    path(
        "<int:pk>/update/",
        views.PayrollUpdateView.as_view(),
        name="update",
    ),

    path(
        "<int:pk>/delete/",
        views.PayrollDeleteView.as_view(),
        name="delete",
    ),

]
