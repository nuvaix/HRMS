
PENDING = "PENDING"
APPROVED = "APPROVED"
REJECTED = "REJECTED"
CANCELLED = "CANCELLED"

STATUS_CHOICES = [
    (PENDING, "Pending"),
    (APPROVED, "Approved"),
    (REJECTED, "Rejected"),
    (CANCELLED, "Cancelled"),
]


ANNUAL = "ANNUAL"
SICK = "SICK"
CASUAL = "CASUAL"
MATERNITY = "MATERNITY"
PATERNITY = "PATERNITY"
UNPAID = "UNPAID"

LEAVE_TYPE_CHOICES = [
    (ANNUAL, "Annual Leave"),
    (SICK, "Sick Leave"),
    (CASUAL, "Casual Leave"),
    (MATERNITY, "Maternity Leave"),
    (PATERNITY, "Paternity Leave"),
    (UNPAID, "Unpaid Leave"),
]
