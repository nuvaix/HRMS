from django.contrib import admin

# Register your models here.

from django.contrib import admin
from .models import Member


@admin.register(Member)
class MemberAdmin(admin.ModelAdmin):

    list_display = (
        "employee_id",
        "user",
        "department",
        "position",
        "status",
    )

    list_filter = (
        "department",
        "status",
    )

    search_fields = (
        "employee_id",
        "user__first_name",
        "user__last_name",
        "department",
    )
