from django.shortcuts import render

# Create your views here.

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import redirect
from django.urls import reverse_lazy
from django.views import View
from django.views.generic import (
    ListView,
    CreateView,
    DetailView,
    UpdateView,
    DeleteView,
)

from .models import Shift
from .forms import ShiftCreateForm

from .selectors import (
    search_shifts,
    get_shift,
)

from .services import (
    create_shift,
    update_shift,
    delete_shift,
)


class ShiftListView(LoginRequiredMixin, ListView):

    model = Shift

    template_name = "shifts/list.html"

    context_object_name = "shifts"

    paginate_by = 10

    def get_queryset(self):

        return search_shifts(

            self.request.GET.get("search")

        )


class ShiftCreateView(LoginRequiredMixin, CreateView):

    model = Shift

    form_class = ShiftCreateForm

    template_name = "shifts/create.html"

    success_url = reverse_lazy("shifts:list")

    def form_valid(self, form):

        create_shift(

            form=form,

        )

        messages.success(

            self.request,

            "Shift created successfully."

        )

        return redirect(self.success_url)

    def form_invalid(self, form):

        print(form.errors)

        return super().form_invalid(form)


class ShiftDetailView(LoginRequiredMixin, DetailView):

    model = Shift

    template_name = "shifts/detail.html"

    context_object_name = "shift"

    def get_object(self):

        return get_shift(

            self.kwargs["pk"]

        )



class ShiftUpdateView(LoginRequiredMixin, UpdateView):

    model = Shift

    form_class = ShiftCreateForm

    template_name = "shifts/update.html"

    success_url = reverse_lazy("shifts:list")

    def form_valid(self, form):

        update_shift(

            form=form,

        )

        messages.success(

            self.request,

            "Shift updated successfully."

        )

        return redirect(self.success_url)


class ShiftDeleteView(LoginRequiredMixin, DeleteView):

    model = Shift

    template_name = "shifts/delete.html"

    success_url = reverse_lazy("shifts:list")

    def form_valid(self, form):

        delete_shift(

            shift=self.object,

        )

        messages.success(

            self.request,

            "Shift deleted successfully."

        )

        return redirect(self.success_url)
