# Document Types
CONTRACT = "CONTRACT"
CV = "CV"
CERTIFICATE = "CERTIFICATE"
ID_CARD = "ID_CARD"
MEDICAL = "MEDICAL"
PERFORMANCE = "PERFORMANCE"
OTHER = "OTHER"

DOCUMENT_TYPE_CHOICES = [
    (CONTRACT, "Employment Contract"),
    (CV, "Curriculum Vitae"),
    (CERTIFICATE, "Certificate"),
    (ID_CARD, "ID Card"),
    (MEDICAL, "Medical Record"),
    (PERFORMANCE, "Performance Review"),
    (OTHER, "Other"),
]


# Status
ACTIVE = "ACTIVE"
ARCHIVED = "ARCHIVED"

DOCUMENT_STATUS_CHOICES = [
    (ACTIVE, "Active"),
    (ARCHIVED, "Archived"),
]
