
from django.contrib.auth import get_user_model
from django.db import transaction
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer

from .models import (
    Conversation,
    Message,
    MessageReceipt,
    MessageReaction,
    Notification,
)

#from notification.services import create_notification

User = get_user_model()


@transaction.atomic
def create_private_conversation(user1, user2):
    """
    Create or return an existing private conversation.
    """

    conversation = (
        Conversation.objects
        .filter(
            conversation_type=Conversation.PRIVATE,
            participants=user1,
        )
        .filter(
            participants=user2,
        )
        .distinct()
        .first()
    )

    if conversation:
        return conversation

    conversation = Conversation.objects.create(
        conversation_type=Conversation.PRIVATE,
        created_by=user1,
    )

    conversation.participants.add(user1, user2)

    return conversation


@transaction.atomic
def create_group_conversation(
    creator,
    name,
    participants,
):
    """
    Create a group conversation.
    """

    conversation = Conversation.objects.create(
        conversation_type=Conversation.GROUP,
        name=name,
        created_by=creator,
    )

    conversation.participants.add(creator)

    conversation.participants.add(*participants)

    return conversation


@transaction.atomic
def send_message(
    conversation,
    sender,
    body="",
    image=None,
    attachment=None,
    reply_to=None,
):
    """
    Save a message and create receipts.
    """

    message = Message.objects.create(
        conversation=conversation,
        sender=sender,
        body=body,
        image=image,
        attachment=attachment,
        reply_to=reply_to,
    )

    recipients = (
        conversation.participants
        .exclude(id=sender.id)
    )

    receipts = [

        MessageReceipt(
            message=message,
            user=user,
        )

        for user in recipients

    ]

    MessageReceipt.objects.bulk_create(receipts)


    for participant in conversation.participants.exclude(

        id=sender.id

    ):

        create_notification(

            recipient=participant,

            sender=sender,

            conversation=conversation,

            title="New Message",

            body=body if body else "Sent an attachment.",

        )

    return message


@transaction.atomic
def edit_message(
    message,
    new_body,
):
    """
    Edit a message.
    """

    message.body = new_body

    message.edited = True

    message.save(
        update_fields=[
            "body",
            "edited",
            "updated_at",
        ]
    )

    return message


@transaction.atomic
def delete_message(message):
    """
    Soft delete a message.
    """

    message.deleted = True

    message.save(
        update_fields=[
            "deleted",
        ]
    )


@transaction.atomic
def add_reaction(
    message,
    user,
    emoji,
):
    """
    Toggle a reaction.
    """

    reaction = MessageReaction.objects.filter(
        message=message,
        user=user,
        emoji=emoji,
    )

    if reaction.exists():

        reaction.delete()

        return None

    return MessageReaction.objects.create(
        message=message,
        user=user,
        emoji=emoji,
    )


@transaction.atomic
def mark_message_delivered(
    receipt,
):
    """
    Mark a receipt as delivered.
    """

    if receipt.delivered_at is None:

        from django.utils import timezone

        receipt.delivered_at = timezone.now()

        receipt.save(
            update_fields=[
                "delivered_at",
            ]
        )


@transaction.atomic
def mark_message_read(
    receipt,
):
    """
    Mark a receipt as read.
    """

    if receipt.read_at is None:

        from django.utils import timezone

        receipt.read_at = timezone.now()

        receipt.save(
            update_fields=[
                "read_at",
            ]
        )


def create_notification(

    recipient,

    sender,

    conversation,

    title,

    body,

    notification_type=Notification.MESSAGE,

):

    notification = Notification.objects.create(

        recipient=recipient,

        sender=sender,

        conversation=conversation,

        notification_type=notification_type,

        title=title,

        body=body,

    )

    channel_layer = get_channel_layer()

    async_to_sync(

        channel_layer.group_send

    )(

        f"notifications_{recipient.id}",

        {

            "type": "notification",

            "data": {

                "id": str(notification.id),

                "title": notification.title,

                "body": notification.body,

                "conversation_id": conversation.id if conversation else None,

            },

        },

    )

    return notification

