from django.contrib.auth.mixins import LoginRequiredMixin


class StaffRequiredMixin(LoginRequiredMixin):

    """
    All workforce pages require login.
    """

    pass
