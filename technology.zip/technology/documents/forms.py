from django import forms

from .models import Document


class DocumentCreateForm(forms.ModelForm):

    class Meta:

        model = Document

        fields = [

            "member",
            "title",
            "document_type",
            "file",
            "description",
            "status",

        ]

        widgets = {

            "member": forms.Select(
                attrs={
                    "class": "form-select",
                }
            ),

            "title": forms.TextInput(
                attrs={
                    "class": "form-control",
                }
            ),

            "document_type": forms.Select(
                attrs={
                    "class": "form-select",
                }
            ),

            "file": forms.ClearableFileInput(
                attrs={
                    "class": "form-control",
                }
            ),

            "description": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "rows": 4,
                }
            ),

            "status": forms.Select(
                attrs={
                    "class": "form-select",
                }
            ),

        }

    def clean_file(self):

        file = self.cleaned_data["file"]

        if file.size > 20 * 1024 * 1024:

            raise forms.ValidationError(
                "Maximum file size is 20MB."
            )

        return file
