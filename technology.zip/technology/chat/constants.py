"""
Chat Constants
"""

# ==========================
# Conversation Types
# ==========================

PRIVATE = "PRIVATE"
GROUP = "GROUP"
DEPARTMENT = "DEPARTMENT"

CONVERSATION_TYPES = [

    (PRIVATE, "Private"),

    (GROUP, "Group"),

    (DEPARTMENT, "Department"),

]


# ==========================
# Message Types
# ==========================

TEXT = "TEXT"
IMAGE = "IMAGE"
FILE = "FILE"
VOICE = "VOICE"

MESSAGE_TYPES = [

    (TEXT, "Text"),

    (IMAGE, "Image"),

    (FILE, "File"),

    (VOICE, "Voice"),

]


# ==========================
# Message Status
# ==========================

SENT = "SENT"
DELIVERED = "DELIVERED"
READ = "READ"

MESSAGE_STATUS = [

    (SENT, "Sent"),

    (DELIVERED, "Delivered"),

    (READ, "Read"),

]


# ==========================
# Online Status
# ==========================

ONLINE = "ONLINE"
OFFLINE = "OFFLINE"
AWAY = "AWAY"
BUSY = "BUSY"

ONLINE_STATUS = [

    (ONLINE, "Online"),

    (OFFLINE, "Offline"),

    (AWAY, "Away"),

    (BUSY, "Busy"),

]
