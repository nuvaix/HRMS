from decimal import Decimal

from .models import Payroll

def calculate_gross_salary(payroll):

    gross = (

        payroll.basic_salary

        + payroll.housing_allowance

        + payroll.transport_allowance

        + payroll.medical_allowance

        + payroll.overtime

        + payroll.bonus

    )

    return gross


def calculate_total_deductions(payroll):

    deductions = (

        payroll.tax

        + payroll.pension

        + payroll.deductions

    )

    return deductions


def calculate_net_salary(payroll):

    gross = calculate_gross_salary(payroll)

    deduction = calculate_total_deductions(payroll)

    return gross - deduction


def update_payroll_totals(payroll):

    payroll.gross_salary = calculate_gross_salary(

        payroll

    )

    payroll.net_salary = calculate_net_salary(

        payroll

    )

    payroll.save()

    return payroll



def create_payroll(**data):

    payroll = Payroll.objects.create(

        **data

    )

    update_payroll_totals(

        payroll

    )

    return payroll


def update_payroll(

    payroll,

    **data,

):

    for key, value in data.items():

        setattr(

            payroll,

            key,

            value,

        )

    payroll.save()

    update_payroll_totals(

        payroll

    )

    return payroll


def delete_payroll(payroll):

    payroll.delete()
