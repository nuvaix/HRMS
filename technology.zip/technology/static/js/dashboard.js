document.addEventListener("DOMContentLoaded", () => {

    // ==========================
    // Live Clock
    // ==========================

    function updateClock() {

        const now = new Date();

        const date = now.toLocaleDateString(undefined, {
            weekday: "long",
            month: "short",
            day: "numeric",
            year: "numeric"
        });

        const time = now.toLocaleTimeString();

        const liveDate = document.getElementById("liveDate");
        const liveClock = document.getElementById("liveClock");

        if (liveDate) liveDate.textContent = date;
        if (liveClock) liveClock.textContent = time;
    }

    updateClock();

    setInterval(updateClock, 1000);

    // ==========================
    // Animated Counters
    // ==========================

    document.querySelectorAll(".stat-content h3").forEach(counter => {

        const target = parseInt(counter.innerText) || 0;

        let count = 0;

        const speed = 25;

        const timer = setInterval(() => {

            count++;

            counter.innerText = count;

            if (count >= target) {

                clearInterval(timer);

            }

        }, speed);

    });

});
