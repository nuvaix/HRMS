
from django import forms

from .models import Conversation, Message


class ConversationForm(forms.ModelForm):
    """
    Create a new conversation.
    """

    class Meta:
        model = Conversation

        fields = [
            "name",
            "conversation_type",
            "participants",
        ]

        widgets = {
            "name": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Conversation name",
                }
            ),
            "conversation_type": forms.Select(
                attrs={
                    "class": "form-select",
                }
            ),
            "participants": forms.SelectMultiple(
                attrs={
                    "class": "form-select",
                }
            ),
        }


class MessageForm(forms.ModelForm):
    """
    Send a chat message.
    """

    class Meta:
        model = Message

        fields = [
            "body",
            "image",
            "attachment",
        ]

        widgets = {
            "body": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "id": "message-input",
                    "rows": 1,
                    "placeholder": "Type a message...",
                    "autocomplete": "off",
                }
            ),
            "image": forms.ClearableFileInput(
                attrs={
                    "class": "form-control",
                    "accept": "image/*",
                }
            ),
            "attachment": forms.ClearableFileInput(
                attrs={
                    "class": "form-control",
                }
            ),
        }

    def clean(self):
        cleaned_data = super().clean()

        body = cleaned_data.get("body")
        image = cleaned_data.get("image")
        attachment = cleaned_data.get("attachment")

        if not body and not image and not attachment:
            raise forms.ValidationError(
                "A message must contain text, an image, or an attachment."
            )

        return cleaned_data
