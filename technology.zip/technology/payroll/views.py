from django.shortcuts import render

# Create your views here.

from django.contrib import messages
from django.urls import reverse_lazy
from django.views.generic import (
    ListView,
    DetailView,
    CreateView,
    UpdateView,
    DeleteView,
)

from .forms import PayrollForm
from .models import Payroll
from .services import (
    update_payroll_totals,
)
from .selectors import (
    payroll_statistics,
)

class PayrollListView(ListView):

    model = Payroll

    template_name = "payroll/list.html"

    context_object_name = "payrolls"

    paginate_by = 10

    def get_queryset(self):

        return (

            Payroll.objects

            .select_related(

                "member",

                "member__user",

            )

            .order_by(

                "-year",

                "-month",

            )

        )

    def get_context_data(self, **kwargs):

        context = super().get_context_data(**kwargs)

        context.update(

            payroll_statistics()

        )

        return context

class PayrollDetailView(DetailView):

    model = Payroll

    template_name = "payroll/detail.html"

    context_object_name = "payroll"


class PayrollCreateView(CreateView):

    model = Payroll

    form_class = PayrollForm

    template_name = "payroll/create.html"

    success_url = reverse_lazy(

        "payroll:list"

    )

    def form_valid(self, form):

        response = super().form_valid(form)

        update_payroll_totals(

            self.object

        )

        messages.success(

            self.request,

            "Payroll created successfully.",

        )

        return response


class PayrollUpdateView(UpdateView):

    model = Payroll

    form_class = PayrollForm

    template_name = "payroll/update.html"

    success_url = reverse_lazy(

        "payroll:list"

    )

    def form_valid(self, form):

        response = super().form_valid(form)

        update_payroll_totals(

            self.object

        )

        messages.success(

            self.request,

            "Payroll updated successfully.",

        )

        return response


class PayrollDeleteView(DeleteView):

    model = Payroll

    template_name = "payroll/delete.html"

    success_url = reverse_lazy(

        "payroll:list"

    )

    context_object_name = "payroll"

    def delete(

        self,

        request,

        *args,

        **kwargs,

    ):

        messages.success(

            request,

            "Payroll deleted successfully.",

        )

        return super().delete(

            request,

            *args,

            **kwargs,

        )
