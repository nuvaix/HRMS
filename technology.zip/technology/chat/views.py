
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
from django.shortcuts import get_object_or_404, redirect, render
from django.http import HttpResponseRedirect

from .forms import (
    ConversationForm,
    MessageForm,
)

from .models import (
    Conversation,
    Message,
)

from .selectors import (
    chat_statistics,
    get_conversation,
    get_conversation_messages,
    get_recent_conversations,
    get_user_conversations,
    search_users,
    get_unread_notification_count,
    get_recent_notifications,
)

from .services import (
    create_private_conversation,
    send_message,
)

User = get_user_model()


@login_required
def inbox(request):

    conversations = get_user_conversations(request.user)

    context = {
        "conversations": conversations,
        "chat_stats": chat_statistics(),
    }

    return render(
        request,
        "chat/inbox.html",
        context,
    )


@login_required
def conversation(request, pk):

    conversation = get_object_or_404(
        Conversation,
        pk=pk,
    )

    if request.user not in conversation.participants.all():
        messages.error(
            request,
            "You are not allowed to access this conversation.",
        )
        return redirect("chat:inbox")

    message_form = MessageForm()
    

    other_user = (

        conversation.participants

        .exclude(id=request.user.id)

        .first()

    )


    context = {

        "conversation": conversation,

        "messages_list": get_conversation_messages(
            conversation
        ),

        "form": message_form,

        "other_user": other_user,

    }

    return render(
        request,
        "chat/conversation.html",
        context,
    )


@login_required
def send(request, pk):

    conversation = get_object_or_404(
        Conversation,
        pk=pk,
    )

    if request.method != "POST":
        return redirect(
            "chat:conversation",
            pk=pk,
        )

    form = MessageForm(
        request.POST,
        request.FILES,
    )

    if form.is_valid():

        send_message(

            conversation=conversation,

            sender=request.user,

            body=form.cleaned_data.get("body", ""),

            image=form.cleaned_data.get("image"),

            attachment=form.cleaned_data.get("attachment"),

        )

    return redirect(
        "chat:conversation",
        pk=pk,
    )


@login_required
def new_chat(request):

    query = request.GET.get(
        "q",
        "",
    )

    users = search_users(

        query=query,

        current_user=request.user,

    )

    context = {

        "users": users,

        "query": query,

    }

    return render(
        request,
        "chat/new_chat.html",
        context,
    )


@login_required
def start_chat(request, user_id):

    other_user = get_object_or_404(
        User,
        pk=user_id,
    )

    conversation = create_private_conversation(
        request.user,
        other_user,
    )

    return redirect(
        "chat:conversation",
        pk=conversation.id,
    )


@login_required
def notifications(request):

    context = {

        "notifications": get_recent_notifications(

            request.user,

            limit=20,

        ),

        "unread_count": get_unread_notification_count(

            request.user,

        ),

    }

    return render(

        request,

        "chat/notifications.html",

        context,

    )


@login_required
def mark_notification_read(request, pk):

    notification = get_object_or_404(

        Notification,

        pk=pk,

        recipient=request.user,

    )

    notification.is_read = True

    notification.save(update_fields=["is_read"])

    if notification.conversation:

        return redirect(

            "chat:conversation",

            pk=notification.conversation.id,

        )

    return redirect("chat:notifications")


@login_required
def mark_all_notifications_read(request):

    Notification.objects.filter(

        recipient=request.user,

        is_read=False,

    ).update(

        is_read=True,

    )

    return redirect("chat:notifications")

