from django import forms
from django.contrib.auth import get_user_model

from .models import Member

User = get_user_model()


class MemberCreateForm(forms.ModelForm):

    first_name = forms.CharField(
        max_length=150,
        widget=forms.TextInput(
            attrs={"class": "form-control"}
        ),
    )

    last_name = forms.CharField(
        max_length=150,
        widget=forms.TextInput(
            attrs={"class": "form-control"}
        ),
    )

    email = forms.EmailField(
        widget=forms.EmailInput(
            attrs={"class": "form-control"}
        ),
    )

    password = forms.CharField(
        required=False,
        widget=forms.PasswordInput(
            attrs={"class": "form-control"}
        ),
    )

    class Meta:

        model = Member

        fields = [
            "employee_id",
            "phone",
            "department",
            "position",
            "gender",
            "address",
            "profile_picture",
            "status",
        ]

        widgets = {

            "employee_id": forms.TextInput(
                attrs={"class": "form-control"}
            ),

            "phone": forms.TextInput(
                attrs={"class": "form-control"}
            ),

            "department": forms.TextInput(
                attrs={"class": "form-control"}
            ),

            "position": forms.TextInput(
                attrs={"class": "form-control"}
            ),

            "gender": forms.Select(
                attrs={"class": "form-select"}
            ),

            "address": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "rows": 3,
                }
            ),

            "profile_picture": forms.ClearableFileInput(
                attrs={"class": "form-control"}
            ),

            "status": forms.Select(
                attrs={"class": "form-select"}
            ),

        }

    def __init__(self, *args, **kwargs):

        super().__init__(*args, **kwargs)

        if self.instance.pk:

            self.fields["first_name"].initial = (
                self.instance.user.first_name
            )

            self.fields["last_name"].initial = (
                self.instance.user.last_name
            )

            self.fields["email"].initial = (
                self.instance.user.email
            )

    def clean_email(self):

        email = self.cleaned_data["email"]

        queryset = User.objects.filter(
            email=email
        )

        if self.instance.pk:

            queryset = queryset.exclude(
                pk=self.instance.user.pk
            )

        if queryset.exists():

            raise forms.ValidationError(
                "A user with this email already exists."
            )

        return email
