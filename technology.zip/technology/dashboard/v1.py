from django.contrib.auth.decorators import login_required
from django.shortcuts import render

from members.models import Member
from documents.models import Document

from leaves.selectors import (
    leave_statistics,
    get_recent_leaves,
)

from shifts.selectors import (
    shift_statistics,
    get_recent_shifts,
)

from attendance.selectors import (
    attendance_statistics,
    get_recent_attendance,
)

from payroll.selectors import (
    payroll_statistics,
    get_recent_payroll,
)


@login_required
def home(request):

    # ==========================================
    # Member Statistics
    # ==========================================

    total_members = Member.objects.count()

    active_members = Member.objects.filter(
        status="ACTIVE"
    ).count()

    inactive_members = Member.objects.exclude(
        status="ACTIVE"
    ).count()

    recent_members = (
        Member.objects
        .select_related("user")
        .order_by("-created_at")[:5]
    )

    # ==========================================
    # Document Statistics
    # ==========================================

    total_documents = Document.objects.count()

    active_documents = Document.objects.filter(
        status="ACTIVE"
    ).count()

    inactive_documents = Document.objects.exclude(
        status="ACTIVE"
    ).count()

    recent_documents = (
        Document.objects
        .select_related(
            "member",
            "member__user",
        )
        .order_by("-created_at")[:5]
    )

    # ==========================================
    # Leave Statistics
    # ==========================================

    leave_stats = leave_statistics()

    recent_leaves = get_recent_leaves()

    # ==========================================
    # Shift Statistics
    # ==========================================

    shift_stats = shift_statistics()

    recent_shifts = get_recent_shifts()


    # ==========================================
    # Attendeance Statistics
    # ==========================================

    attendance_stats = attendance_statistics()

    recent_attendance = get_recent_attendance()

    # ==========================
    # Payroll Statistics
    # ==========================

    payroll_stats = payroll_statistics()

    recent_payroll = get_recent_payroll()

    # ==========================================
    # Context
    # ==========================================



    context = {

        # Members
        "total_members": total_members,
        "active_members": active_members,
        "inactive_members": inactive_members,
        "recent_members": recent_members,

        # Documents
        "total_documents": total_documents,
        "active_documents": active_documents,
        "inactive_documents": inactive_documents,
        "recent_documents": recent_documents,

        # Recent Leaves
        "recent_leaves": recent_leaves,

        # Recent Shifts
        "recent_shifts": recent_shifts,

        # Leave Statistics
        **leave_stats,

        # Shift Statistics
        "total_shifts": shift_stats["total_shifts"],
        "active_shifts": shift_stats["active_shifts"],
        "inactive_shifts": shift_stats["inactive_shifts"],
        "morning_shifts": shift_stats["morning_shifts"],
        "afternoon_shifts": shift_stats["afternoon_shifts"],
        "evening_shifts": shift_stats["evening_shifts"],
        "night_shifts": shift_stats["night_shifts"],
        "recent_shifts": recent_shifts,
        **shift_stats,
        **shift_stats,

        # attendance
        "total_attendance": attendance_stats["total_attendance"],

        "present_count": attendance_stats["present_count"],

        "absent_count": attendance_stats["absent_count"],

        "late_count": attendance_stats["late_count"],

        "half_day_count": attendance_stats["half_day_count"],

        "recent_attendance": recent_attendance,
        **attendance_stats,

        # Payroll

        "total_payroll": payroll_stats["total_payroll"],

        "gross_payroll": payroll_stats["gross_payroll"],

        "net_payroll": payroll_stats["net_payroll"],

        "total_tax": payroll_stats["total_tax"],

        "total_pension": payroll_stats["total_pension"],

        "total_bonus": payroll_stats["total_bonus"],

        "total_overtime": payroll_stats["total_overtime"],

        "recent_payroll": recent_payroll,


    }

    context.update(leave_stats)

    return render(
        request,
        "dashboard/home.html",
        context,
    )
