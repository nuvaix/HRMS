document.addEventListener("DOMContentLoaded", function () {

    const badge = document.getElementById("notification-badge");

    const protocol = window.location.protocol === "https:" ? "wss" : "ws";

    const socket = new WebSocket(
        `${protocol}://${window.location.host}/ws/notifications/`
    );

    socket.onopen = function () {

        console.log("Notification socket connected");

    };

    socket.onmessage = function (event) {

        const data = JSON.parse(event.data);

        console.log(data);

        if (badge) {

            let count = parseInt(badge.innerText) || 0;

            badge.innerText = count + 1;

            badge.style.display = "inline-block";

        }

    };

    socket.onclose = function () {

        console.log("Notification socket closed");

    };

});
