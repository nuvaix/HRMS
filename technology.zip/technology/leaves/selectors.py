from django.db.models import Q

from .constants import PENDING

from .models import Leave


def search_leaves(
    search=None,
    status=None,
    leave_type=None,
):

    queryset = (
        Leave.objects
        .select_related(
            "member",
            "member__user",
            "approved_by",
        )
        .order_by("-created_at")
    )

    if search:

        queryset = queryset.filter(

            Q(member__employee_id__icontains=search)

            |

            Q(member__user__first_name__icontains=search)

            |

            Q(member__user__last_name__icontains=search)

            |

            Q(member__user__email__icontains=search)

        )

    if status:

        queryset = queryset.filter(
            status=status
        )

    if leave_type:

        queryset = queryset.filter(
            leave_type=leave_type
        )

    return queryset



def get_recent_leaves(limit=5):

    return (
        Leave.objects
        .select_related(
            "member",
            "member__user",
        )
        .order_by("-created_at")[:limit]
    )


from .constants import (
    PENDING,
    APPROVED,
    REJECTED,
)


def leave_statistics():

    queryset = Leave.objects.all()

    return {

        "total_leaves": queryset.count(),

        "pending_leaves": queryset.filter(
            status=PENDING
        ).count(),

        "approved_leaves": queryset.filter(
            status=APPROVED
        ).count(),

        "rejected_leaves": queryset.filter(
            status=REJECTED
        ).count(),

    }


def member_leave_history(member):

    return (

        Leave.objects

        .filter(member=member)

        .order_by("-start_date")

    )



def pending_leave_requests():

    return (

        Leave.objects

        .filter(status=PENDING)

        .select_related(
            "member",
            "member__user",
        )

        .order_by("start_date")

    )
