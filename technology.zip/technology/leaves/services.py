from .models import Leave

from django.utils import timezone

from .constants import APPROVED

from .models import Leave

from .constants import REJECTED

from .constants import CANCELLED


def create_leave(form):

    leave = form.save()

    return leave

def approve_leave(leave, user):

    leave.status = APPROVED

    leave.approved_by = user

    leave.approved_at = timezone.now()

    leave.save()

    return leave


def reject_leave(leave, user):

    leave.status = REJECTED

    leave.approved_by = user

    leave.approved_at = timezone.now()

    leave.save()

    return leave



def cancel_leave(leave):

    leave.status = CANCELLED

    leave.save()

    return leave
