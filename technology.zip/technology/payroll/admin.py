from django.contrib import admin

# Register your models here.


from django.contrib import admin

from .models import Payroll


@admin.register(Payroll)
class PayrollAdmin(admin.ModelAdmin):

    list_display = (

        "member",

        "month",

        "year",

        "gross_salary",

        "net_salary",

        "status",

        "created_at",

    )

    list_filter = (

        "status",

        "month",

        "year",

    )

    search_fields = (

        "member__user__first_name",

        "member__user__last_name",

        "member__employee_id",

    )

    ordering = (

        "-year",

        "-month",

        "member",

    )

    readonly_fields = (

        "gross_salary",

        "net_salary",

        "created_at",

        "updated_at",

    )

    fieldsets = (

        (

            "Employee Information",

            {

                "fields": (

                    "member",

                    "month",

                    "year",

                ),

            },

        ),

        (

            "Salary",

            {

                "fields": (

                    "basic_salary",

                    "housing_allowance",

                    "transport_allowance",

                    "medical_allowance",

                    "bonus",

                    "overtime",

                ),

            },

        ),

        (

            "Deductions",

            {

                "fields": (

                    "tax",

                    "pension",

                    "deductions",

                ),

            },

        ),

        (

            "Results",

            {

                "fields": (

                    "gross_salary",

                    "net_salary",

                ),

            },

        ),

        (

            "Other",

            {

                "fields": (

                    "status",

                    "remarks",

                ),

            },

        ),

        (

            "Audit",

            {

                "fields": (

                    "created_at",

                    "updated_at",

                ),

            },

        ),

    )
