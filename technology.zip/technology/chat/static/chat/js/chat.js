
/*
========================================
Enterprise Chat
chat.js
========================================
*/

let chatSocket = null;

/*
========================================
Get Conversation ID
========================================
*/

const conversationContainer = document.getElementById("messages-container");

const conversationId = conversationContainer
    ? conversationContainer.dataset.conversationId
    : null;


/*
========================================
Connect
========================================
*/

function connectSocket() {

    if (!conversationId) {

        console.log("No conversation selected.");

        return;

    }

    const protocol =
        window.location.protocol === "https:"
            ? "wss://"
            : "ws://";

    const socketURL =
        protocol +
        window.location.host +
        "/ws/chat/" +
        conversationId +
        "/";

    chatSocket = new WebSocket(socketURL);

    chatSocket.onopen = function () {

        console.log("✅ WebSocket Connected");

    };


    chatSocket.onclose = function () {

        console.log("❌ WebSocket Closed");

        /*
         * Auto reconnect after 2 seconds
         */

        setTimeout(connectSocket, 2000);

    };


    chatSocket.onerror = function (error) {

        console.error(error);

    };



    chatSocket.onmessage = function(event){

    	const data = JSON.parse(event.data);

    	/*
    	======================
    	Typing Indicator
    	======================
    	*/

    	if(data.event === "typing"){

            const indicator =
            	document.getElementById("typing-indicator");

            if(indicator){

            	indicator.classList.remove("d-none");

            	indicator.innerHTML =
                    `${data.sender} is typing...`;

            }	

            return;

    	}

    	if(data.event === "stop_typing"){

            const indicator =
            	document.getElementById("typing-indicator");

            if(indicator){

            	indicator.classList.add("d-none");

            }

            return;

    	}

	

	if(data.event === "delivered"){

    	    const status = document.getElementById(

        	"status-" + data.message_id

    	    );

    	    if(status){

		status.innerHTML = `
		<span class="status-delivered">

		<i class="fa-solid fa-check-double"></i>

		Delivered

		</span>
		`;

    	    }

    	    return;

    	}


	if(data.event === "read"){

    	    const status = document.getElementById(

        	"status-" + data.message_id

    	    );

    	    if(status){

	    	status.innerHTML = `
		<span class="status-read">

		<i class="fa-solid fa-check-double"></i>

		Read

		</span>
		`;

    	    }

    	    return;

	}

	

	if(data.event === "presence"){

    	    const badge = document.getElementById(

        	"presence-" + data.user_id

   	);

    	if(!badge){

            return;

    	}

    	if(data.is_online){

            badge.innerHTML = `

            	<small class="badge bg-success">

                    <i class="fa-solid fa-circle"></i>

                    Online

                </small>

            `;

    	}else{

            badge.innerHTML = `

            	<small class="text-muted">

		    Last seen ${data.last_seen}

            	</small>

            `;

    	}

    	return;

    }



    	/*
    	======================
    	Normal Message
    	======================
    	*/

    	const container =
            document.getElementById("messages-container");

    	if(!container) return;

    	const html = `

            <div class="message-wrapper">

            	<div class="message-content">

                    <div class="message-header">

                    	<strong>${data.sender}</strong>

                    	<small>${data.created_at}</small>

                    </div>

                    <div class="message-bubble">

                    	${data.message}

                    </div>

            	</div>

            </div>

    	`;

    	container.insertAdjacentHTML(
            "beforeend",
            html
    	);

    	container.scrollTop =
            container.scrollHeight;

    };



}


/*
========================================
Start Connection
========================================
*/

connectSocket();


/*
========================================
Textarea Auto Resize
========================================
*/

const input = document.getElementById("message-input");

if (input) {

    input.addEventListener("input", function () {

        this.style.height = "auto";

        this.style.height = this.scrollHeight + "px";

    });

}


const form =
    document.getElementById("message-form");

if(form){

    form.addEventListener("submit", function(e){

        e.preventDefault();

        const input =
            document.getElementById("message-input");

        if(input.value.trim() === "")
            return;

        chatSocket.send(

            JSON.stringify({

                message: input.value

            })

        );

        input.value = "";

        input.style.height = "44px";

    });

}


let typingTimeout = null;

if(input){

    input.addEventListener("input", function(){

        chatSocket.send(

            JSON.stringify({

                event: "typing"

            })

        );

        clearTimeout(typingTimeout);

        typingTimeout = setTimeout(function(){

            chatSocket.send(

                JSON.stringify({

                    event: "stop_typing"

                })

            );

        }, 1000);

    });

}


const uploadForm = document.getElementById("message-form");

if(uploadForm){

    uploadForm.addEventListener(

        "submit",

        function(e){

            e.preventDefault();

            uploadMessage();

        }

    );

}


function uploadMessage(){

    const form = document.getElementById(

        "message-form"

    );

    const formData = new FormData(form);

    const xhr = new XMLHttpRequest();

    xhr.open(

        "POST",

        form.action,

        true

    );

    xhr.setRequestHeader(

        "X-CSRFToken",

        document.querySelector(

            "[name=csrfmiddlewaretoken]"

        ).value

    );

    xhr.upload.addEventListener(

        "progress",

        function(e){

            if(e.lengthComputable){

                const percent = Math.round(

                    (e.loaded / e.total) * 100

                );

                updateUploadProgress(percent);

            }

        }

    );

    xhr.onload = function(){

        updateUploadProgress(100);

        form.reset();

        setTimeout(

            hideProgress,

            800

        );

    };

    xhr.send(formData);

}

function updateUploadProgress(percent){

    const container = document.getElementById(

        "upload-progress-container"

    );

    const bar = document.getElementById(

        "upload-progress"

    );

    container.style.display = "block";

    bar.style.width = percent + "%";

    bar.innerHTML = percent + "%";

}


function hideProgress(){

    document.getElementById(

        "upload-progress-container"

    ).style.display = "none";


}


const dropZone = document.getElementById("drop-zone");

const overlay = document.getElementById("drop-overlay");

if(dropZone){

    ["dragenter","dragover"].forEach(eventName=>{

        dropZone.addEventListener(

            eventName,

            function(e){

                e.preventDefault();

                overlay.classList.add("active");

            }

        );

    });

    ["dragleave","drop"].forEach(eventName=>{

        dropZone.addEventListener(

            eventName,

            function(e){

                e.preventDefault();

                overlay.classList.remove("active");

            }

        );

    });

}


dropZone.addEventListener(

    "drop",

    function(e){

        const files = e.dataTransfer.files;

        if(files.length===0){

            return;

        }

        const input = document.querySelector(

            'input[type="file"]'

        );

        input.files = files;

        uploadMessage();

    }

);

