from .models import Shift


def create_shift(*, form):

    shift = form.save()

    return shift

def update_shift(*, form):

    shift = form.save()

    return shift

def delete_shift(*, shift):

    shift.delete()
