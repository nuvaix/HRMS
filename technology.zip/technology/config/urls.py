"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

urlpatterns = [

    path("admin/", admin.site.urls),

    path("", include("dashboard.urls")),

    path("accounts/", include("accounts.urls")),

    path("members/", include("members.urls")),

    path("documents/", include("documents.urls")),

    path("leaves/", include("leaves.urls")),

    path("shifts/", include("shifts.urls")),

    path("attendance/", include("attendance.urls")),

    path("payroll/", include(("payroll.urls", "payroll"), namespace="payroll")),

    path("chat/", include("chat.urls")),
]

if settings.DEBUG:
    urlpatterns += static(
        settings.MEDIA_URL,
        document_root=settings.MEDIA_ROOT,
    )
