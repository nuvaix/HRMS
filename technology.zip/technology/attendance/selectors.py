from django.db.models import Count
from django.utils import timezone
from .models import Attendance

from .constants import (
    PRESENT,
    ABSENT,
    LATE,
    HALF_DAY,
    ON_LEAVE,
)


def attendance_statistics():

    queryset = Attendance.objects.all()

    return {

        "total_attendance": queryset.count(),

        "present_count": queryset.filter(
            status=PRESENT
        ).count(),

        "absent_count": queryset.filter(
            status=ABSENT
        ).count(),

        "late_count": queryset.filter(
            status=LATE
        ).count(),

        "half_day_count": queryset.filter(
            status=HALF_DAY
        ).count(),

        "leave_count": queryset.filter(
            status=ON_LEAVE
        ).count(),

    }



def get_recent_attendance():

    return (

        Attendance.objects

        .select_related(
            "member",
            "member__user",
        )

        .order_by("-date", "-created_at")[:5]

    )



def get_today_attendance():

    today = timezone.localdate()

    return (

        Attendance.objects

        .filter(
            date=today
        )

        .select_related(
            "member",
            "member__user",
        )

        .order_by("member__user__first_name")

    )


def attendance_by_status():

    return (

        Attendance.objects

        .values("status")

        .annotate(
            total=Count("id")
        )

        .order_by("status")

    )


def get_member_attendance(member):

    return (

        Attendance.objects

        .filter(
            member=member
        )

        .order_by("-date")

    )


def get_attendance_by_date(date):

    return (

        Attendance.objects

        .filter(
            date=date
        )

        .select_related(
            "member",
            "member__user",
        )

    )
