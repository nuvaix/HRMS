from django.db import models

# Create your models here.

from django.conf import settings
from django.db import models

from members.models import Member

from .constants import (
    DOCUMENT_TYPE_CHOICES,
    DOCUMENT_STATUS_CHOICES,
    ACTIVE,
)


class Document(models.Model):

    member = models.ForeignKey(
        Member,
        on_delete=models.CASCADE,
        related_name="documents",
    )

    title = models.CharField(
        max_length=255,
    )

    document_type = models.CharField(
        max_length=30,
        choices=DOCUMENT_TYPE_CHOICES,
    )

    file = models.FileField(
        upload_to="documents/",
    )

    description = models.TextField(
        blank=True,
    )

    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        related_name="uploaded_documents",
    )

    status = models.CharField(
        max_length=20,
        choices=DOCUMENT_STATUS_CHOICES,
        default=ACTIVE,
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
    )

    updated_at = models.DateTimeField(
        auto_now=True,
    )

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.title} - {self.member.employee_id}"
