from django.conf import settings
from django.db import models

from .constants import (
    STATUS_CHOICES,
    GENDER_CHOICES,
    ACTIVE,
)


class Member(models.Model):

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="member",
    )

    employee_id = models.CharField(
        max_length=20,
        unique=True,
    )

    phone = models.CharField(
        max_length=20,
    )

    department = models.CharField(
        max_length=100,
    )

    position = models.CharField(
        max_length=100,
    )

    gender = models.CharField(
        max_length=10,
        choices=GENDER_CHOICES,
    )

    address = models.TextField()

    profile_picture = models.ImageField(
        upload_to="members/",
        blank=True,
        null=True,
    )

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default=ACTIVE,
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
    )

    updated_at = models.DateTimeField(
        auto_now=True,
    )

    class Meta:
        ordering = ["employee_id"]

    def __str__(self):
        return f"{self.user.get_full_name()} ({self.employee_id})"
