from django.contrib.auth import get_user_model
from django.db import transaction

from .models import Member

User = get_user_model()


@transaction.atomic
def create_member(form):
    """
    Create both the User account and the Member profile
    as a single database transaction.
    """

    user = User.objects.create_user(
        email=form.cleaned_data["email"],
        password=form.cleaned_data["password"],
        first_name=form.cleaned_data["first_name"],
        last_name=form.cleaned_data["last_name"],
    )

    member = form.save(commit=False)
    member.user = user
    member.save()

    return member
