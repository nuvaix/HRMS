{% extends "base/base.html" %}

{% block title %}
Delete Shift
{% endblock %}

{% block content %}

<div class="container-fluid">

    <div class="row justify-content-center mt-5">

        <div class="col-lg-6">

            <div class="card shadow border-0">

                <div class="card-header bg-danger text-white">

                    <h4 class="mb-0">

                        <i class="bi bi-exclamation-triangle-fill"></i>

                        Delete Shift

                    </h4>

                </div>

                <div class="card-body">

                    <p class="fs-5">

                        Are you sure you want to permanently delete this shift?

                    </p>

                    <hr>

                    <table class="table table-borderless">

                        <tr>

                            <th width="35%">

                                Employee

                            </th>

                            <td>

                                {{ object.member.user.get_full_name }}

                            </td>

                        </tr>

                        <tr>

                            <th>

                                Employee ID

                            </th>

                            <td>

                                {{ object.member.employee_id }}

                            </td>

                        </tr>

                        <tr>

                            <th>

                                Shift Type

                            </th>

                            <td>

                                {{ object.get_shift_type_display }}

                            </td>

                        </tr>

                        <tr>

                            <th>

                                Start Time

                            </th>

                            <td>

                                {{ object.start_time }}

                            </td>

                        </tr>

                        <tr>

                            <th>

                                End Time

                            </th>

                            <td>

                                {{ object.end_time }}

                            </td>

                        </tr>

                        <tr>

                            <th>

                                Status

                            </th>

                            <td>

                                {% if object.status == "ACTIVE" %}

                                    <span class="badge bg-success">

                                        Active

                                    </span>

                                {% else %}

                                    <span class="badge bg-secondary">

                                        {{ object.get_status_display }}

                                    </span>

                                {% endif %}

                            </td>

                        </tr>

                    </table>

                    <div class="alert alert-warning">

                        <i class="bi bi-exclamation-circle-fill"></i>

                        This action cannot be undone.

                    </div>

                    <form method="post">

                        {% csrf_token %}

                        <div class="d-flex justify-content-end">

                            <a
                                href="{% url 'shifts:detail' object.pk %}"
                                class="btn btn-secondary me-2">

                                Cancel

                            </a>

                            <button
                                type="submit"
                                class="btn btn-danger">

                                <i class="bi bi-trash-fill"></i>

                                Delete Shift

                            </button>

                        </div>

                    </form>

                </div>

            </div>

        </div>

    </div>

</div>

{% endblock %}
