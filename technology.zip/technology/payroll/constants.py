ACTIVE = "ACTIVE"

INACTIVE = "INACTIVE"

STATUS_CHOICES = [

    (ACTIVE, "Active"),

    (INACTIVE, "Inactive"),

]
