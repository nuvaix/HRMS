PRESENT = "PRESENT"

ABSENT = "ABSENT"

LATE = "LATE"

HALF_DAY = "HALF_DAY"

ON_LEAVE = "ON_LEAVE"


ATTENDANCE_STATUS = (

    (PRESENT, "Present"),

    (ABSENT, "Absent"),

    (LATE, "Late"),

    (HALF_DAY, "Half Day"),

    (ON_LEAVE, "On Leave"),

)
