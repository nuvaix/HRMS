from django.shortcuts import render

# Create your views here.
from django.http import FileResponse, Http404
from django.views import View
from .selectors import search_documents
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import redirect
from django.urls import reverse_lazy
from django.views.generic import (
    CreateView,
    ListView,
    DetailView,
    UpdateView,
    DeleteView,
)

from .forms import DocumentCreateForm
from .models import Document
from .services import create_document


class DocumentListView(LoginRequiredMixin, ListView):

    model = Document
    template_name = "documents/list.html"
    context_object_name = "documents"
    paginate_by = 10

    def get_queryset(self):

        return search_documents(
            self.request.GET.get("search")
        )


class DocumentCreateView(LoginRequiredMixin, CreateView):

    model = Document
    form_class = DocumentCreateForm
    template_name = "documents/create.html"
    success_url = reverse_lazy("documents:list")

    def form_valid(self, form):

        create_document(
            form=form,
            uploaded_by=self.request.user,
        )

        messages.success(
            self.request,
            "Document uploaded successfully."
        )

        return redirect(self.success_url)

    def form_invalid(self, form):

        print(form.errors)

        return super().form_invalid(form)

class DocumentUpdateView(LoginRequiredMixin, UpdateView):

    model = Document
    form_class = DocumentCreateForm
    template_name = "documents/update.html"
    success_url = reverse_lazy("documents:list")

    def form_valid(self, form):

        messages.success(
            self.request,
            "Document updated successfully."
        )

        return super().form_valid(form)

class DocumentDeleteView(LoginRequiredMixin, DeleteView):

    model = Document
    template_name = "documents/delete.html"
    success_url = reverse_lazy("documents:list")

    def form_valid(self, form):

        messages.success(
            self.request,
            "Document deleted successfully."
        )

        return super().form_valid(form)


class DocumentDownloadView(LoginRequiredMixin, View):

    def get(self, request, pk):

        try:
            document = Document.objects.get(pk=pk)

        except Document.DoesNotExist:
            raise Http404("Document not found.")

        response = FileResponse(
            document.file.open("rb"),
            as_attachment=True,
            filename=document.file.name.split("/")[-1],
        )

        return response


class DocumentDetailView(LoginRequiredMixin, DetailView):

    model = Document
    template_name = "documents/detail.html"
    context_object_name = "document"
