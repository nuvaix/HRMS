from django.db import models

# Create your models here.

from django.db import models

from members.models import Member

from .constants import SHIFT_TYPES


class Shift(models.Model):

    member = models.ForeignKey(
        Member,
        on_delete=models.CASCADE,
        related_name="shifts",
    )

    shift_type = models.CharField(
        max_length=20,
        choices=SHIFT_TYPES,
    )

    start_time = models.TimeField()

    end_time = models.TimeField()

    is_active = models.BooleanField(
        default=True,
    )

    notes = models.TextField(
        blank=True,
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
    )

    updated_at = models.DateTimeField(
        auto_now=True,
    )

    class Meta:

        ordering = ["-created_at"]

    def __str__(self):

        return f"{self.member.user.get_full_name()} - {self.get_shift_type_display()}"
