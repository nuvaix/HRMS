document.addEventListener("DOMContentLoaded", () => {

const sidebar = document.getElementById("sidebar");

const toggle = document.getElementById("sidebarToggle");

if (toggle) {

toggle.addEventListener("click", () => {

sidebar.classList.toggle("show");

});

}

});
