
import os

from django.core.exceptions import ValidationError

from PIL import Image


MAX_FILE_SIZE = 25 * 1024 * 1024      # 25 MB

MAX_IMAGE_SIZE = 10 * 1024 * 1024     # 10 MB


ALLOWED_DOCUMENTS = {

    ".pdf",
    ".doc",
    ".docx",
    ".xls",
    ".xlsx",
    ".ppt",
    ".pptx",
    ".txt",
    ".zip",

}


ALLOWED_IMAGES = {

    ".jpg",
    ".jpeg",
    ".png",
    ".gif",
    ".webp",

}


def validate_document(file):

    if not file:

        return

    if file.size == 0:

        raise ValidationError(

            "Empty files are not allowed."

        )

    if file.size > MAX_FILE_SIZE:

        raise ValidationError(

            "Maximum file size is 25 MB."

        )

    extension = os.path.splitext(

        file.name

    )[1].lower()

    if extension not in ALLOWED_DOCUMENTS:

        raise ValidationError(

            "Unsupported document type."

        )


def validate_image(file):

    if not file:

        return

    if file.size == 0:

        raise ValidationError(

            "Empty images are not allowed."

        )

    if file.size > MAX_IMAGE_SIZE:

        raise ValidationError(

            "Images cannot exceed 10 MB."

        )

    extension = os.path.splitext(

        file.name

    )[1].lower()

    if extension not in ALLOWED_IMAGES:

        raise ValidationError(

            "Unsupported image type."

        )

    try:

        image = Image.open(file)

        image.verify()

        file.seek(0)

    except Exception:

        raise ValidationError(

            "Invalid image."

        )


