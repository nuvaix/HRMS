from django import forms

from .models import Shift


class ShiftCreateForm(forms.ModelForm):

    class Meta:

        model = Shift

        fields = [

            "member",
            "shift_type",
            "start_time",
            "end_time",
            "is_active",
            "notes",

        ]

        widgets = {

            "member": forms.Select(
                attrs={
                    "class": "form-select",
                }
            ),

            "shift_type": forms.Select(
                attrs={
                    "class": "form-select",
                }
            ),

            "start_time": forms.TimeInput(
                attrs={
                    "class": "form-control",
                    "type": "time",
                }
            ),

            "end_time": forms.TimeInput(
                attrs={
                    "class": "form-control",
                    "type": "time",
                }
            ),

            "is_active": forms.CheckboxInput(
                attrs={
                    "class": "form-check-input",
                }
            ),

            "notes": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "rows": 4,
                }
            ),

        }

        def clean(self):

            cleaned_data = super().clean()

            start_time = cleaned_data.get("start_time")

            end_time = cleaned_data.get("end_time")

            if start_time and end_time:

                if start_time == end_time:

                    raise forms.ValidationError(

                       "Start time and end time cannot be the same."

                    )

            return cleaned_data
