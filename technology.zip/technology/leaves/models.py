from django.db import models

# Create your models here.


from django.conf import settings
from django.db import models

from members.models import Member

from .constants import (
    PENDING,
    STATUS_CHOICES,
    LEAVE_TYPE_CHOICES,
)


class Leave(models.Model):

    member = models.ForeignKey(
        Member,
        on_delete=models.CASCADE,
        related_name="leaves",
    )

    leave_type = models.CharField(
        max_length=20,
        choices=LEAVE_TYPE_CHOICES,
    )

    start_date = models.DateField()

    end_date = models.DateField()

    total_days = models.PositiveIntegerField(
    default=1,
    )

    reason = models.TextField()

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default=PENDING,
    )

    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="approved_leaves",
    )

    approved_at = models.DateTimeField(
        null=True,
        blank=True,
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
    )

    updated_at = models.DateTimeField(
        auto_now=True,
    )


    class Meta:
        ordering = ["-created_at"]
        
    def save(self, *args, **kwargs):

        self.total_days = (
        self.end_date - self.start_date
        ).days + 1

        super().save(*args, **kwargs)

    def __str__(self):
        return (
            f"{self.member.user.get_full_name()} - "
            f"{self.leave_type}"
        )
