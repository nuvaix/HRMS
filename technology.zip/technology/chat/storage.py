import os
import uuid


def chat_upload_path(instance, filename):

    extension = os.path.splitext(filename)[1].lower()

    name = f"{uuid.uuid4()}{extension}"

    return os.path.join(
        "chat",
        "documents",
        name,
    )


def image_upload_path(instance, filename):

    extension = os.path.splitext(filename)[1].lower()

    name = f"{uuid.uuid4()}{extension}"

    return os.path.join(
        "chat",
        "images",
        name,
    )
