from .models import Notification


def create_notification(

    recipient,

    sender,

    title,

    body,

    conversation=None,

    notification_type=Notification.MESSAGE,

):

    return Notification.objects.create(

        recipient=recipient,

        sender=sender,

        title=title,

        body=body,

        conversation=conversation,

        notification_type=notification_type,

    )
