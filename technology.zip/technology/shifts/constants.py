MORNING = "MORNING"
AFTERNOON = "AFTERNOON"
EVENING = "EVENING"
NIGHT = "NIGHT"

SHIFT_TYPES = [

    (MORNING, "Morning"),

    (AFTERNOON, "Afternoon"),

    (EVENING, "Evening"),

    (NIGHT, "Night"),

]
