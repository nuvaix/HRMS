from .models import Document


def create_document(form, uploaded_by):
    """
    Create and save a new document.
    """

    document = form.save(commit=False)

    document.uploaded_by = uploaded_by

    document.save()

    return document
