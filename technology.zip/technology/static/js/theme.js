document.addEventListener("DOMContentLoaded", () => {

    const body = document.body;

    const button = document.getElementById("themeToggle");

    if (!button) return;

    if (localStorage.getItem("theme") === "dark") {

        body.classList.add("dark-mode");

    }

    button.addEventListener("click", () => {

        body.classList.toggle("dark-mode");

        if (body.classList.contains("dark-mode")) {

            localStorage.setItem("theme", "dark");

        } else {

            localStorage.setItem("theme", "light");

        }

    });

});
