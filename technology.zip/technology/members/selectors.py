from django.db.models import Q

from .models import Member


def search_members(search=None):
    """
    Return members filtered by search term.

    Search includes:
    - Employee ID
    - First Name
    - Last Name
    - Email
    - Department
    - Position
    """

    queryset = (
        Member.objects
        .select_related("user")
        .order_by("employee_id")
    )

    if search:

        queryset = queryset.filter(

            Q(employee_id__icontains=search)

            |

            Q(user__first_name__icontains=search)

            |

            Q(user__last_name__icontains=search)

            |

            Q(user__email__icontains=search)

            |

            Q(department__icontains=search)

            |

            Q(position__icontains=search)

        )

    return queryset
