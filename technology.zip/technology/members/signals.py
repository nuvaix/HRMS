from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import Member


@receiver(post_save, sender=Member)
def member_created(sender, instance, created, **kwargs):

    if created:

        print(f"{instance} created")
