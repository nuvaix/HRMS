from pathlib import Path
import environ
import os

BASE_DIR = Path(__file__).resolve().parent.parent.parent

env = environ.Env()

environ.Env.read_env(BASE_DIR / ".env")

SECRET_KEY = env("SECRET_KEY")

DEBUG = env.bool("DEBUG", default=False)

ALLOWED_HOSTS = env.list("ALLOWED_HOSTS", default=["127.0.0.1"])

DJANGO_APPS = [

    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",

]

THIRD_PARTY_APPS = [

    "rest_framework",
    "crispy_forms",
    "crispy_bootstrap5",
    "import_export",
    "channels",
    "axes",

]

LOCAL_APPS = [

    "accounts",
    "dashboard",
    "members",
    "documents",
    "reports",
    "chat",
    "notifications",
    "shifts",
    "leaves",
    "attendance",
    "payroll",
    "daphne",

]

INSTALLED_APPS = LOCAL_APPS + DJANGO_APPS + THIRD_PARTY_APPS 

MIDDLEWARE = [

    'django.middleware.security.SecurityMiddleware',

    'whitenoise.middleware.WhiteNoiseMiddleware',

    'django.contrib.sessions.middleware.SessionMiddleware',

    'django.middleware.common.CommonMiddleware',

    'django.middleware.csrf.CsrfViewMiddleware',

    'django.contrib.auth.middleware.AuthenticationMiddleware',

    'axes.middleware.AxesMiddleware',

    'django.contrib.messages.middleware.MessageMiddleware',

    'django.middleware.clickjacking.XFrameOptionsMiddleware',

]

ROOT_URLCONF = "config.urls"

TEMPLATES = [

    {

        'BACKEND':'django.template.backends.django.DjangoTemplates',

        'DIRS':[BASE_DIR/"templates"],

        'APP_DIRS':True,

        'OPTIONS':{

            'context_processors':[

                'django.template.context_processors.request',

                'django.contrib.auth.context_processors.auth',

                'django.contrib.messages.context_processors.messages',

            ],

        },

    },

]

DATABASES = {

    "default":{

        "ENGINE":"django.db.backends.postgresql",

        "NAME":env("DB_NAME"),

        "USER":env("DB_USER"),

        "PASSWORD":env("DB_PASSWORD"),

        "HOST":env("DB_HOST"),

        "PORT":env("DB_PORT"),

    }

}

STATIC_URL="/static/"

STATIC_ROOT=BASE_DIR/"staticfiles"

STATICFILES_DIRS=[

    BASE_DIR/"static",

]

MEDIA_URL="/media/"

MEDIA_ROOT=BASE_DIR/"media"

LOGIN_URL="accounts:login"

LOGIN_REDIRECT_URL="dashboard:home"

LOGOUT_REDIRECT_URL="accounts:login"

AUTH_USER_MODEL="accounts.User"



#EMAIL_BACKEND="django.core.mail.backends.smtp.EmailBackend"

#EMAIL_HOST=env("EMAIL_HOST")

#EMAIL_PORT=env.int("EMAIL_PORT")

#EMAIL_HOST_USER=env("EMAIL_HOST_USER")

#EMAIL_HOST_PASSWORD=env("EMAIL_HOST_PASSWORD")

#EMAIL_USE_TLS=True


AUTHENTICATION_BACKENDS = [
    "axes.backends.AxesStandaloneBackend",
    "django.contrib.auth.backends.ModelBackend",
]


EMAIL_BACKEND = env(
    "EMAIL_BACKEND",
    default="django.core.mail.backends.smtp.EmailBackend"
)

EMAIL_HOST = env("EMAIL_HOST")
EMAIL_PORT = env.int("EMAIL_PORT", default=587)
EMAIL_USE_TLS = env.bool("EMAIL_USE_TLS", default=True)

EMAIL_HOST_USER = env("EMAIL_HOST_USER")
EMAIL_HOST_PASSWORD = env("EMAIL_HOST_PASSWORD")

DEFAULT_FROM_EMAIL = env("DEFAULT_FROM_EMAIL")
SERVER_EMAIL = env("SERVER_EMAIL")


ASGI_APPLICATION="config.asgi.application"

CHANNEL_LAYERS={

    "default":{

        "BACKEND":"channels_redis.core.RedisChannelLayer",

        "CONFIG":{

            "hosts":[("127.0.0.1",6379)]

        }

    }

}

REST_FRAMEWORK={

    "DEFAULT_PERMISSION_CLASSES":[

        "rest_framework.permissions.IsAuthenticated",

    ]

}

CRISPY_ALLOWED_TEMPLATE_PACKS="bootstrap5"

CRISPY_TEMPLATE_PACK="bootstrap5"

AUTH_PASSWORD_VALIDATORS=[

    {

        'NAME':'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',

    },

    {

        'NAME':'django.contrib.auth.password_validation.MinimumLengthValidator',

        'OPTIONS':{'min_length':12},

    },

    {

        'NAME':'django.contrib.auth.password_validation.CommonPasswordValidator',

    },

    {

        'NAME':'django.contrib.auth.password_validation.NumericPasswordValidator',

    },

]

SESSION_COOKIE_HTTPONLY=True

CSRF_COOKIE_HTTPONLY=True
#CSRF_COOKIE_HTTPONLY=False

SESSION_COOKIE_SECURE=not DEBUG
#SESSION_COOKIE_SECURE=False

CSRF_COOKIE_SECURE=not DEBUG
#CSRF_COOKIE_SECURE=False

SECURE_BROWSER_XSS_FILTER=True

SECURE_CONTENT_TYPE_NOSNIFF=True

X_FRAME_OPTIONS="DENY"

SECURE_REFERRER_POLICY="same-origin"

SECURE_HSTS_SECONDS=31536000

SECURE_HSTS_INCLUDE_SUBDOMAINS=True

SECURE_HSTS_PRELOAD=True

# ==========================================
# Django Channels
# ==========================================

ASGI_APPLICATION = "config.asgi.application"



# ==========================================
# Redis
# ==========================================

CHANNEL_LAYERS = {

    "default": {

        "BACKEND": "channels_redis.core.RedisChannelLayer",

        "CONFIG": {

            "hosts": [

                ("127.0.0.1", 6379),

            ],

        },

    },

}

