from django.db import models

# Create your models here.

from django.db import models

from members.models import Member

from .constants import ATTENDANCE_STATUS, PRESENT


class Attendance(models.Model):

    member = models.ForeignKey(
        Member,
        on_delete=models.CASCADE,
        related_name="attendance_records",
    )

    date = models.DateField()

    check_in = models.TimeField()

    check_out = models.TimeField(
        blank=True,
        null=True,
    )

    status = models.CharField(
        max_length=20,
        choices=ATTENDANCE_STATUS,
        default=PRESENT,
    )

    remarks = models.TextField(
        blank=True,
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
    )

    updated_at = models.DateTimeField(
        auto_now=True,
    )

    class Meta:

        ordering = ["-date", "-created_at"]

        unique_together = ("member", "date")

    def __str__(self):

        return f"{self.member} - {self.date}"
