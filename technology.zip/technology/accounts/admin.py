from django.contrib import admin

# Register your models here.

from django.contrib import admin

from django.contrib.auth.admin import UserAdmin

from .models import User


@admin.register(User)

class CustomUserAdmin(UserAdmin):

    ordering = ("email",)

    list_display = (
        "email",
        "first_name",
        "last_name",
        "role",
        "is_active",
        "is_verified",
    )

    fieldsets = (

        (None, {
            "fields": (
                "email",
                "password",
            )
        }),

        ("Personal", {
            "fields": (
                "first_name",
                "last_name",
                "phone",
                "avatar",
            )
        }),

        ("Permissions", {
            "fields": (
                "role",
                "is_staff",
                "is_superuser",
                "groups",
                "user_permissions",
            )
        }),

        ("Status", {
            "fields": (
                "is_active",
                "is_verified",
            )
        }),
    )

    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": (
                    "email",
                    "password1",
                    "password2",
                ),
            },
        ),
    )

    search_fields = ("email",)
