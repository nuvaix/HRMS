from django.contrib import admin

# Register your models here.

from django.contrib import admin

from .models import Leave


@admin.register(Leave)
class LeaveAdmin(admin.ModelAdmin):

    list_display = (
        "member",
        "leave_type",
        "start_date",
        "end_date",
        "status",
    )

    list_filter = (
        "leave_type",
        "status",
    )

    search_fields = (
        "member__user__first_name",
        "member__user__last_name",
        "member__employee_id",
    )
